/*
 * Component description for SYSCTRL
 *
 * Copyright (c) 2025 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/*  file generated from device description file (ATDF) version 2019-11-25T23:26:27Z  */
#ifndef _PIC32CMGV00_SYSCTRL_COMPONENT_H_
#define _PIC32CMGV00_SYSCTRL_COMPONENT_H_

/* ************************************************************************** */
/*                    SOFTWARE API DEFINITION FOR SYSCTRL                     */
/* ************************************************************************** */

/* -------- SYSCTRL_INTENCLR : (SYSCTRL Offset: 0x00) (R/W 32) Interrupt Enable Clear -------- */
#define SYSCTRL_INTENCLR_RESETVALUE           _UINT32_(0x00)                                       /*  (SYSCTRL_INTENCLR) Interrupt Enable Clear  Reset Value */

#define SYSCTRL_INTENCLR_XOSCRDY_Pos          _UINT32_(0)                                          /* (SYSCTRL_INTENCLR) XOSC Ready Position */
#define SYSCTRL_INTENCLR_XOSCRDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTENCLR_XOSCRDY_Pos)      /* (SYSCTRL_INTENCLR) XOSC Ready Mask */
#define SYSCTRL_INTENCLR_XOSCRDY(value)       (SYSCTRL_INTENCLR_XOSCRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_XOSCRDY_Pos)) /* Assignment of value for XOSCRDY in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_XOSC32KRDY_Pos       _UINT32_(1)                                          /* (SYSCTRL_INTENCLR) XOSC32K Ready Position */
#define SYSCTRL_INTENCLR_XOSC32KRDY_Msk       (_UINT32_(0x1) << SYSCTRL_INTENCLR_XOSC32KRDY_Pos)   /* (SYSCTRL_INTENCLR) XOSC32K Ready Mask */
#define SYSCTRL_INTENCLR_XOSC32KRDY(value)    (SYSCTRL_INTENCLR_XOSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_XOSC32KRDY_Pos)) /* Assignment of value for XOSC32KRDY in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_OSC32KRDY_Pos        _UINT32_(2)                                          /* (SYSCTRL_INTENCLR) OSC32K Ready Position */
#define SYSCTRL_INTENCLR_OSC32KRDY_Msk        (_UINT32_(0x1) << SYSCTRL_INTENCLR_OSC32KRDY_Pos)    /* (SYSCTRL_INTENCLR) OSC32K Ready Mask */
#define SYSCTRL_INTENCLR_OSC32KRDY(value)     (SYSCTRL_INTENCLR_OSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_OSC32KRDY_Pos)) /* Assignment of value for OSC32KRDY in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_OSC8MRDY_Pos         _UINT32_(3)                                          /* (SYSCTRL_INTENCLR) OSC8M Ready Position */
#define SYSCTRL_INTENCLR_OSC8MRDY_Msk         (_UINT32_(0x1) << SYSCTRL_INTENCLR_OSC8MRDY_Pos)     /* (SYSCTRL_INTENCLR) OSC8M Ready Mask */
#define SYSCTRL_INTENCLR_OSC8MRDY(value)      (SYSCTRL_INTENCLR_OSC8MRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_OSC8MRDY_Pos)) /* Assignment of value for OSC8MRDY in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_DFLLRDY_Pos          _UINT32_(4)                                          /* (SYSCTRL_INTENCLR) DFLL Ready Position */
#define SYSCTRL_INTENCLR_DFLLRDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTENCLR_DFLLRDY_Pos)      /* (SYSCTRL_INTENCLR) DFLL Ready Mask */
#define SYSCTRL_INTENCLR_DFLLRDY(value)       (SYSCTRL_INTENCLR_DFLLRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_DFLLRDY_Pos)) /* Assignment of value for DFLLRDY in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_DFLLOOB_Pos          _UINT32_(5)                                          /* (SYSCTRL_INTENCLR) DFLL Out Of Bounds Position */
#define SYSCTRL_INTENCLR_DFLLOOB_Msk          (_UINT32_(0x1) << SYSCTRL_INTENCLR_DFLLOOB_Pos)      /* (SYSCTRL_INTENCLR) DFLL Out Of Bounds Mask */
#define SYSCTRL_INTENCLR_DFLLOOB(value)       (SYSCTRL_INTENCLR_DFLLOOB_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_DFLLOOB_Pos)) /* Assignment of value for DFLLOOB in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_DFLLLCKF_Pos         _UINT32_(6)                                          /* (SYSCTRL_INTENCLR) DFLL Lock Fine Position */
#define SYSCTRL_INTENCLR_DFLLLCKF_Msk         (_UINT32_(0x1) << SYSCTRL_INTENCLR_DFLLLCKF_Pos)     /* (SYSCTRL_INTENCLR) DFLL Lock Fine Mask */
#define SYSCTRL_INTENCLR_DFLLLCKF(value)      (SYSCTRL_INTENCLR_DFLLLCKF_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_DFLLLCKF_Pos)) /* Assignment of value for DFLLLCKF in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_DFLLLCKC_Pos         _UINT32_(7)                                          /* (SYSCTRL_INTENCLR) DFLL Lock Coarse Position */
#define SYSCTRL_INTENCLR_DFLLLCKC_Msk         (_UINT32_(0x1) << SYSCTRL_INTENCLR_DFLLLCKC_Pos)     /* (SYSCTRL_INTENCLR) DFLL Lock Coarse Mask */
#define SYSCTRL_INTENCLR_DFLLLCKC(value)      (SYSCTRL_INTENCLR_DFLLLCKC_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_DFLLLCKC_Pos)) /* Assignment of value for DFLLLCKC in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_DFLLRCS_Pos          _UINT32_(8)                                          /* (SYSCTRL_INTENCLR) DFLL Reference Clock Stopped Position */
#define SYSCTRL_INTENCLR_DFLLRCS_Msk          (_UINT32_(0x1) << SYSCTRL_INTENCLR_DFLLRCS_Pos)      /* (SYSCTRL_INTENCLR) DFLL Reference Clock Stopped Mask */
#define SYSCTRL_INTENCLR_DFLLRCS(value)       (SYSCTRL_INTENCLR_DFLLRCS_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_DFLLRCS_Pos)) /* Assignment of value for DFLLRCS in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_BOD33RDY_Pos         _UINT32_(9)                                          /* (SYSCTRL_INTENCLR) BOD33 Ready Position */
#define SYSCTRL_INTENCLR_BOD33RDY_Msk         (_UINT32_(0x1) << SYSCTRL_INTENCLR_BOD33RDY_Pos)     /* (SYSCTRL_INTENCLR) BOD33 Ready Mask */
#define SYSCTRL_INTENCLR_BOD33RDY(value)      (SYSCTRL_INTENCLR_BOD33RDY_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_BOD33RDY_Pos)) /* Assignment of value for BOD33RDY in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_BOD33DET_Pos         _UINT32_(10)                                         /* (SYSCTRL_INTENCLR) BOD33 Detection Position */
#define SYSCTRL_INTENCLR_BOD33DET_Msk         (_UINT32_(0x1) << SYSCTRL_INTENCLR_BOD33DET_Pos)     /* (SYSCTRL_INTENCLR) BOD33 Detection Mask */
#define SYSCTRL_INTENCLR_BOD33DET(value)      (SYSCTRL_INTENCLR_BOD33DET_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_BOD33DET_Pos)) /* Assignment of value for BOD33DET in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_B33SRDY_Pos          _UINT32_(11)                                         /* (SYSCTRL_INTENCLR) BOD33 Synchronization Ready Position */
#define SYSCTRL_INTENCLR_B33SRDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTENCLR_B33SRDY_Pos)      /* (SYSCTRL_INTENCLR) BOD33 Synchronization Ready Mask */
#define SYSCTRL_INTENCLR_B33SRDY(value)       (SYSCTRL_INTENCLR_B33SRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENCLR_B33SRDY_Pos)) /* Assignment of value for B33SRDY in the SYSCTRL_INTENCLR register */
#define SYSCTRL_INTENCLR_Msk                  _UINT32_(0x00000FFF)                                 /* (SYSCTRL_INTENCLR) Register Mask  */


/* -------- SYSCTRL_INTENSET : (SYSCTRL Offset: 0x04) (R/W 32) Interrupt Enable Set -------- */
#define SYSCTRL_INTENSET_RESETVALUE           _UINT32_(0x00)                                       /*  (SYSCTRL_INTENSET) Interrupt Enable Set  Reset Value */

#define SYSCTRL_INTENSET_XOSCRDY_Pos          _UINT32_(0)                                          /* (SYSCTRL_INTENSET) XOSC Ready Position */
#define SYSCTRL_INTENSET_XOSCRDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTENSET_XOSCRDY_Pos)      /* (SYSCTRL_INTENSET) XOSC Ready Mask */
#define SYSCTRL_INTENSET_XOSCRDY(value)       (SYSCTRL_INTENSET_XOSCRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_XOSCRDY_Pos)) /* Assignment of value for XOSCRDY in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_XOSC32KRDY_Pos       _UINT32_(1)                                          /* (SYSCTRL_INTENSET) XOSC32K Ready Position */
#define SYSCTRL_INTENSET_XOSC32KRDY_Msk       (_UINT32_(0x1) << SYSCTRL_INTENSET_XOSC32KRDY_Pos)   /* (SYSCTRL_INTENSET) XOSC32K Ready Mask */
#define SYSCTRL_INTENSET_XOSC32KRDY(value)    (SYSCTRL_INTENSET_XOSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_XOSC32KRDY_Pos)) /* Assignment of value for XOSC32KRDY in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_OSC32KRDY_Pos        _UINT32_(2)                                          /* (SYSCTRL_INTENSET) OSC32K Ready Position */
#define SYSCTRL_INTENSET_OSC32KRDY_Msk        (_UINT32_(0x1) << SYSCTRL_INTENSET_OSC32KRDY_Pos)    /* (SYSCTRL_INTENSET) OSC32K Ready Mask */
#define SYSCTRL_INTENSET_OSC32KRDY(value)     (SYSCTRL_INTENSET_OSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_OSC32KRDY_Pos)) /* Assignment of value for OSC32KRDY in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_OSC8MRDY_Pos         _UINT32_(3)                                          /* (SYSCTRL_INTENSET) OSC8M Ready Position */
#define SYSCTRL_INTENSET_OSC8MRDY_Msk         (_UINT32_(0x1) << SYSCTRL_INTENSET_OSC8MRDY_Pos)     /* (SYSCTRL_INTENSET) OSC8M Ready Mask */
#define SYSCTRL_INTENSET_OSC8MRDY(value)      (SYSCTRL_INTENSET_OSC8MRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_OSC8MRDY_Pos)) /* Assignment of value for OSC8MRDY in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_DFLLRDY_Pos          _UINT32_(4)                                          /* (SYSCTRL_INTENSET) DFLL Ready Position */
#define SYSCTRL_INTENSET_DFLLRDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTENSET_DFLLRDY_Pos)      /* (SYSCTRL_INTENSET) DFLL Ready Mask */
#define SYSCTRL_INTENSET_DFLLRDY(value)       (SYSCTRL_INTENSET_DFLLRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_DFLLRDY_Pos)) /* Assignment of value for DFLLRDY in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_DFLLOOB_Pos          _UINT32_(5)                                          /* (SYSCTRL_INTENSET) DFLL Out Of Bounds Position */
#define SYSCTRL_INTENSET_DFLLOOB_Msk          (_UINT32_(0x1) << SYSCTRL_INTENSET_DFLLOOB_Pos)      /* (SYSCTRL_INTENSET) DFLL Out Of Bounds Mask */
#define SYSCTRL_INTENSET_DFLLOOB(value)       (SYSCTRL_INTENSET_DFLLOOB_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_DFLLOOB_Pos)) /* Assignment of value for DFLLOOB in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_DFLLLCKF_Pos         _UINT32_(6)                                          /* (SYSCTRL_INTENSET) DFLL Lock Fine Position */
#define SYSCTRL_INTENSET_DFLLLCKF_Msk         (_UINT32_(0x1) << SYSCTRL_INTENSET_DFLLLCKF_Pos)     /* (SYSCTRL_INTENSET) DFLL Lock Fine Mask */
#define SYSCTRL_INTENSET_DFLLLCKF(value)      (SYSCTRL_INTENSET_DFLLLCKF_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_DFLLLCKF_Pos)) /* Assignment of value for DFLLLCKF in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_DFLLLCKC_Pos         _UINT32_(7)                                          /* (SYSCTRL_INTENSET) DFLL Lock Coarse Position */
#define SYSCTRL_INTENSET_DFLLLCKC_Msk         (_UINT32_(0x1) << SYSCTRL_INTENSET_DFLLLCKC_Pos)     /* (SYSCTRL_INTENSET) DFLL Lock Coarse Mask */
#define SYSCTRL_INTENSET_DFLLLCKC(value)      (SYSCTRL_INTENSET_DFLLLCKC_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_DFLLLCKC_Pos)) /* Assignment of value for DFLLLCKC in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_DFLLRCS_Pos          _UINT32_(8)                                          /* (SYSCTRL_INTENSET) DFLL Reference Clock Stopped Position */
#define SYSCTRL_INTENSET_DFLLRCS_Msk          (_UINT32_(0x1) << SYSCTRL_INTENSET_DFLLRCS_Pos)      /* (SYSCTRL_INTENSET) DFLL Reference Clock Stopped Mask */
#define SYSCTRL_INTENSET_DFLLRCS(value)       (SYSCTRL_INTENSET_DFLLRCS_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_DFLLRCS_Pos)) /* Assignment of value for DFLLRCS in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_BOD33RDY_Pos         _UINT32_(9)                                          /* (SYSCTRL_INTENSET) BOD33 Ready Position */
#define SYSCTRL_INTENSET_BOD33RDY_Msk         (_UINT32_(0x1) << SYSCTRL_INTENSET_BOD33RDY_Pos)     /* (SYSCTRL_INTENSET) BOD33 Ready Mask */
#define SYSCTRL_INTENSET_BOD33RDY(value)      (SYSCTRL_INTENSET_BOD33RDY_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_BOD33RDY_Pos)) /* Assignment of value for BOD33RDY in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_BOD33DET_Pos         _UINT32_(10)                                         /* (SYSCTRL_INTENSET) BOD33 Detection Position */
#define SYSCTRL_INTENSET_BOD33DET_Msk         (_UINT32_(0x1) << SYSCTRL_INTENSET_BOD33DET_Pos)     /* (SYSCTRL_INTENSET) BOD33 Detection Mask */
#define SYSCTRL_INTENSET_BOD33DET(value)      (SYSCTRL_INTENSET_BOD33DET_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_BOD33DET_Pos)) /* Assignment of value for BOD33DET in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_B33SRDY_Pos          _UINT32_(11)                                         /* (SYSCTRL_INTENSET) BOD33 Synchronization Ready Position */
#define SYSCTRL_INTENSET_B33SRDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTENSET_B33SRDY_Pos)      /* (SYSCTRL_INTENSET) BOD33 Synchronization Ready Mask */
#define SYSCTRL_INTENSET_B33SRDY(value)       (SYSCTRL_INTENSET_B33SRDY_Msk & (_UINT32_(value) << SYSCTRL_INTENSET_B33SRDY_Pos)) /* Assignment of value for B33SRDY in the SYSCTRL_INTENSET register */
#define SYSCTRL_INTENSET_Msk                  _UINT32_(0x00000FFF)                                 /* (SYSCTRL_INTENSET) Register Mask  */


/* -------- SYSCTRL_INTFLAG : (SYSCTRL Offset: 0x08) (R/W 32) Interrupt Flag Status and Clear -------- */
#define SYSCTRL_INTFLAG_RESETVALUE            _UINT32_(0x00)                                       /*  (SYSCTRL_INTFLAG) Interrupt Flag Status and Clear  Reset Value */

#define SYSCTRL_INTFLAG_XOSCRDY_Pos           _UINT32_(0)                                          /* (SYSCTRL_INTFLAG) XOSC Ready Position */
#define SYSCTRL_INTFLAG_XOSCRDY_Msk           (_UINT32_(0x1) << SYSCTRL_INTFLAG_XOSCRDY_Pos)       /* (SYSCTRL_INTFLAG) XOSC Ready Mask */
#define SYSCTRL_INTFLAG_XOSCRDY(value)        (SYSCTRL_INTFLAG_XOSCRDY_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_XOSCRDY_Pos)) /* Assignment of value for XOSCRDY in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_XOSC32KRDY_Pos        _UINT32_(1)                                          /* (SYSCTRL_INTFLAG) XOSC32K Ready Position */
#define SYSCTRL_INTFLAG_XOSC32KRDY_Msk        (_UINT32_(0x1) << SYSCTRL_INTFLAG_XOSC32KRDY_Pos)    /* (SYSCTRL_INTFLAG) XOSC32K Ready Mask */
#define SYSCTRL_INTFLAG_XOSC32KRDY(value)     (SYSCTRL_INTFLAG_XOSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_XOSC32KRDY_Pos)) /* Assignment of value for XOSC32KRDY in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_OSC32KRDY_Pos         _UINT32_(2)                                          /* (SYSCTRL_INTFLAG) OSC32K Ready Position */
#define SYSCTRL_INTFLAG_OSC32KRDY_Msk         (_UINT32_(0x1) << SYSCTRL_INTFLAG_OSC32KRDY_Pos)     /* (SYSCTRL_INTFLAG) OSC32K Ready Mask */
#define SYSCTRL_INTFLAG_OSC32KRDY(value)      (SYSCTRL_INTFLAG_OSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_OSC32KRDY_Pos)) /* Assignment of value for OSC32KRDY in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_OSC8MRDY_Pos          _UINT32_(3)                                          /* (SYSCTRL_INTFLAG) OSC8M Ready Position */
#define SYSCTRL_INTFLAG_OSC8MRDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTFLAG_OSC8MRDY_Pos)      /* (SYSCTRL_INTFLAG) OSC8M Ready Mask */
#define SYSCTRL_INTFLAG_OSC8MRDY(value)       (SYSCTRL_INTFLAG_OSC8MRDY_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_OSC8MRDY_Pos)) /* Assignment of value for OSC8MRDY in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_DFLLRDY_Pos           _UINT32_(4)                                          /* (SYSCTRL_INTFLAG) DFLL Ready Position */
#define SYSCTRL_INTFLAG_DFLLRDY_Msk           (_UINT32_(0x1) << SYSCTRL_INTFLAG_DFLLRDY_Pos)       /* (SYSCTRL_INTFLAG) DFLL Ready Mask */
#define SYSCTRL_INTFLAG_DFLLRDY(value)        (SYSCTRL_INTFLAG_DFLLRDY_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_DFLLRDY_Pos)) /* Assignment of value for DFLLRDY in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_DFLLOOB_Pos           _UINT32_(5)                                          /* (SYSCTRL_INTFLAG) DFLL Out Of Bounds Position */
#define SYSCTRL_INTFLAG_DFLLOOB_Msk           (_UINT32_(0x1) << SYSCTRL_INTFLAG_DFLLOOB_Pos)       /* (SYSCTRL_INTFLAG) DFLL Out Of Bounds Mask */
#define SYSCTRL_INTFLAG_DFLLOOB(value)        (SYSCTRL_INTFLAG_DFLLOOB_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_DFLLOOB_Pos)) /* Assignment of value for DFLLOOB in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_DFLLLCKF_Pos          _UINT32_(6)                                          /* (SYSCTRL_INTFLAG) DFLL Lock Fine Position */
#define SYSCTRL_INTFLAG_DFLLLCKF_Msk          (_UINT32_(0x1) << SYSCTRL_INTFLAG_DFLLLCKF_Pos)      /* (SYSCTRL_INTFLAG) DFLL Lock Fine Mask */
#define SYSCTRL_INTFLAG_DFLLLCKF(value)       (SYSCTRL_INTFLAG_DFLLLCKF_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_DFLLLCKF_Pos)) /* Assignment of value for DFLLLCKF in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_DFLLLCKC_Pos          _UINT32_(7)                                          /* (SYSCTRL_INTFLAG) DFLL Lock Coarse Position */
#define SYSCTRL_INTFLAG_DFLLLCKC_Msk          (_UINT32_(0x1) << SYSCTRL_INTFLAG_DFLLLCKC_Pos)      /* (SYSCTRL_INTFLAG) DFLL Lock Coarse Mask */
#define SYSCTRL_INTFLAG_DFLLLCKC(value)       (SYSCTRL_INTFLAG_DFLLLCKC_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_DFLLLCKC_Pos)) /* Assignment of value for DFLLLCKC in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_DFLLRCS_Pos           _UINT32_(8)                                          /* (SYSCTRL_INTFLAG) DFLL Reference Clock Stopped Position */
#define SYSCTRL_INTFLAG_DFLLRCS_Msk           (_UINT32_(0x1) << SYSCTRL_INTFLAG_DFLLRCS_Pos)       /* (SYSCTRL_INTFLAG) DFLL Reference Clock Stopped Mask */
#define SYSCTRL_INTFLAG_DFLLRCS(value)        (SYSCTRL_INTFLAG_DFLLRCS_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_DFLLRCS_Pos)) /* Assignment of value for DFLLRCS in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_BOD33RDY_Pos          _UINT32_(9)                                          /* (SYSCTRL_INTFLAG) BOD33 Ready Position */
#define SYSCTRL_INTFLAG_BOD33RDY_Msk          (_UINT32_(0x1) << SYSCTRL_INTFLAG_BOD33RDY_Pos)      /* (SYSCTRL_INTFLAG) BOD33 Ready Mask */
#define SYSCTRL_INTFLAG_BOD33RDY(value)       (SYSCTRL_INTFLAG_BOD33RDY_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_BOD33RDY_Pos)) /* Assignment of value for BOD33RDY in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_BOD33DET_Pos          _UINT32_(10)                                         /* (SYSCTRL_INTFLAG) BOD33 Detection Position */
#define SYSCTRL_INTFLAG_BOD33DET_Msk          (_UINT32_(0x1) << SYSCTRL_INTFLAG_BOD33DET_Pos)      /* (SYSCTRL_INTFLAG) BOD33 Detection Mask */
#define SYSCTRL_INTFLAG_BOD33DET(value)       (SYSCTRL_INTFLAG_BOD33DET_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_BOD33DET_Pos)) /* Assignment of value for BOD33DET in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_B33SRDY_Pos           _UINT32_(11)                                         /* (SYSCTRL_INTFLAG) BOD33 Synchronization Ready Position */
#define SYSCTRL_INTFLAG_B33SRDY_Msk           (_UINT32_(0x1) << SYSCTRL_INTFLAG_B33SRDY_Pos)       /* (SYSCTRL_INTFLAG) BOD33 Synchronization Ready Mask */
#define SYSCTRL_INTFLAG_B33SRDY(value)        (SYSCTRL_INTFLAG_B33SRDY_Msk & (_UINT32_(value) << SYSCTRL_INTFLAG_B33SRDY_Pos)) /* Assignment of value for B33SRDY in the SYSCTRL_INTFLAG register */
#define SYSCTRL_INTFLAG_Msk                   _UINT32_(0x00000FFF)                                 /* (SYSCTRL_INTFLAG) Register Mask  */


/* -------- SYSCTRL_PCLKSR : (SYSCTRL Offset: 0x0C) ( R/ 32) Power and Clocks Status -------- */
#define SYSCTRL_PCLKSR_RESETVALUE             _UINT32_(0x00)                                       /*  (SYSCTRL_PCLKSR) Power and Clocks Status  Reset Value */

#define SYSCTRL_PCLKSR_XOSCRDY_Pos            _UINT32_(0)                                          /* (SYSCTRL_PCLKSR) XOSC Ready Position */
#define SYSCTRL_PCLKSR_XOSCRDY_Msk            (_UINT32_(0x1) << SYSCTRL_PCLKSR_XOSCRDY_Pos)        /* (SYSCTRL_PCLKSR) XOSC Ready Mask */
#define SYSCTRL_PCLKSR_XOSCRDY(value)         (SYSCTRL_PCLKSR_XOSCRDY_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_XOSCRDY_Pos)) /* Assignment of value for XOSCRDY in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_XOSC32KRDY_Pos         _UINT32_(1)                                          /* (SYSCTRL_PCLKSR) XOSC32K Ready Position */
#define SYSCTRL_PCLKSR_XOSC32KRDY_Msk         (_UINT32_(0x1) << SYSCTRL_PCLKSR_XOSC32KRDY_Pos)     /* (SYSCTRL_PCLKSR) XOSC32K Ready Mask */
#define SYSCTRL_PCLKSR_XOSC32KRDY(value)      (SYSCTRL_PCLKSR_XOSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_XOSC32KRDY_Pos)) /* Assignment of value for XOSC32KRDY in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_OSC32KRDY_Pos          _UINT32_(2)                                          /* (SYSCTRL_PCLKSR) OSC32K Ready Position */
#define SYSCTRL_PCLKSR_OSC32KRDY_Msk          (_UINT32_(0x1) << SYSCTRL_PCLKSR_OSC32KRDY_Pos)      /* (SYSCTRL_PCLKSR) OSC32K Ready Mask */
#define SYSCTRL_PCLKSR_OSC32KRDY(value)       (SYSCTRL_PCLKSR_OSC32KRDY_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_OSC32KRDY_Pos)) /* Assignment of value for OSC32KRDY in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_OSC8MRDY_Pos           _UINT32_(3)                                          /* (SYSCTRL_PCLKSR) OSC8M Ready Position */
#define SYSCTRL_PCLKSR_OSC8MRDY_Msk           (_UINT32_(0x1) << SYSCTRL_PCLKSR_OSC8MRDY_Pos)       /* (SYSCTRL_PCLKSR) OSC8M Ready Mask */
#define SYSCTRL_PCLKSR_OSC8MRDY(value)        (SYSCTRL_PCLKSR_OSC8MRDY_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_OSC8MRDY_Pos)) /* Assignment of value for OSC8MRDY in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_DFLLRDY_Pos            _UINT32_(4)                                          /* (SYSCTRL_PCLKSR) DFLL Ready Position */
#define SYSCTRL_PCLKSR_DFLLRDY_Msk            (_UINT32_(0x1) << SYSCTRL_PCLKSR_DFLLRDY_Pos)        /* (SYSCTRL_PCLKSR) DFLL Ready Mask */
#define SYSCTRL_PCLKSR_DFLLRDY(value)         (SYSCTRL_PCLKSR_DFLLRDY_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_DFLLRDY_Pos)) /* Assignment of value for DFLLRDY in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_DFLLOOB_Pos            _UINT32_(5)                                          /* (SYSCTRL_PCLKSR) DFLL Out Of Bounds Position */
#define SYSCTRL_PCLKSR_DFLLOOB_Msk            (_UINT32_(0x1) << SYSCTRL_PCLKSR_DFLLOOB_Pos)        /* (SYSCTRL_PCLKSR) DFLL Out Of Bounds Mask */
#define SYSCTRL_PCLKSR_DFLLOOB(value)         (SYSCTRL_PCLKSR_DFLLOOB_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_DFLLOOB_Pos)) /* Assignment of value for DFLLOOB in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_DFLLLCKF_Pos           _UINT32_(6)                                          /* (SYSCTRL_PCLKSR) DFLL Lock Fine Position */
#define SYSCTRL_PCLKSR_DFLLLCKF_Msk           (_UINT32_(0x1) << SYSCTRL_PCLKSR_DFLLLCKF_Pos)       /* (SYSCTRL_PCLKSR) DFLL Lock Fine Mask */
#define SYSCTRL_PCLKSR_DFLLLCKF(value)        (SYSCTRL_PCLKSR_DFLLLCKF_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_DFLLLCKF_Pos)) /* Assignment of value for DFLLLCKF in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_DFLLLCKC_Pos           _UINT32_(7)                                          /* (SYSCTRL_PCLKSR) DFLL Lock Coarse Position */
#define SYSCTRL_PCLKSR_DFLLLCKC_Msk           (_UINT32_(0x1) << SYSCTRL_PCLKSR_DFLLLCKC_Pos)       /* (SYSCTRL_PCLKSR) DFLL Lock Coarse Mask */
#define SYSCTRL_PCLKSR_DFLLLCKC(value)        (SYSCTRL_PCLKSR_DFLLLCKC_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_DFLLLCKC_Pos)) /* Assignment of value for DFLLLCKC in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_DFLLRCS_Pos            _UINT32_(8)                                          /* (SYSCTRL_PCLKSR) DFLL Reference Clock Stopped Position */
#define SYSCTRL_PCLKSR_DFLLRCS_Msk            (_UINT32_(0x1) << SYSCTRL_PCLKSR_DFLLRCS_Pos)        /* (SYSCTRL_PCLKSR) DFLL Reference Clock Stopped Mask */
#define SYSCTRL_PCLKSR_DFLLRCS(value)         (SYSCTRL_PCLKSR_DFLLRCS_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_DFLLRCS_Pos)) /* Assignment of value for DFLLRCS in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_BOD33RDY_Pos           _UINT32_(9)                                          /* (SYSCTRL_PCLKSR) BOD33 Ready Position */
#define SYSCTRL_PCLKSR_BOD33RDY_Msk           (_UINT32_(0x1) << SYSCTRL_PCLKSR_BOD33RDY_Pos)       /* (SYSCTRL_PCLKSR) BOD33 Ready Mask */
#define SYSCTRL_PCLKSR_BOD33RDY(value)        (SYSCTRL_PCLKSR_BOD33RDY_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_BOD33RDY_Pos)) /* Assignment of value for BOD33RDY in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_BOD33DET_Pos           _UINT32_(10)                                         /* (SYSCTRL_PCLKSR) BOD33 Detection Position */
#define SYSCTRL_PCLKSR_BOD33DET_Msk           (_UINT32_(0x1) << SYSCTRL_PCLKSR_BOD33DET_Pos)       /* (SYSCTRL_PCLKSR) BOD33 Detection Mask */
#define SYSCTRL_PCLKSR_BOD33DET(value)        (SYSCTRL_PCLKSR_BOD33DET_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_BOD33DET_Pos)) /* Assignment of value for BOD33DET in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_B33SRDY_Pos            _UINT32_(11)                                         /* (SYSCTRL_PCLKSR) BOD33 Synchronization Ready Position */
#define SYSCTRL_PCLKSR_B33SRDY_Msk            (_UINT32_(0x1) << SYSCTRL_PCLKSR_B33SRDY_Pos)        /* (SYSCTRL_PCLKSR) BOD33 Synchronization Ready Mask */
#define SYSCTRL_PCLKSR_B33SRDY(value)         (SYSCTRL_PCLKSR_B33SRDY_Msk & (_UINT32_(value) << SYSCTRL_PCLKSR_B33SRDY_Pos)) /* Assignment of value for B33SRDY in the SYSCTRL_PCLKSR register */
#define SYSCTRL_PCLKSR_Msk                    _UINT32_(0x00000FFF)                                 /* (SYSCTRL_PCLKSR) Register Mask  */


/* -------- SYSCTRL_XOSC : (SYSCTRL Offset: 0x10) (R/W 16) External Multipurpose Crystal Oscillator (XOSC) Control -------- */
#define SYSCTRL_XOSC_RESETVALUE               _UINT16_(0x80)                                       /*  (SYSCTRL_XOSC) External Multipurpose Crystal Oscillator (XOSC) Control  Reset Value */

#define SYSCTRL_XOSC_ENABLE_Pos               _UINT16_(1)                                          /* (SYSCTRL_XOSC) Oscillator Enable Position */
#define SYSCTRL_XOSC_ENABLE_Msk               (_UINT16_(0x1) << SYSCTRL_XOSC_ENABLE_Pos)           /* (SYSCTRL_XOSC) Oscillator Enable Mask */
#define SYSCTRL_XOSC_ENABLE(value)            (SYSCTRL_XOSC_ENABLE_Msk & (_UINT16_(value) << SYSCTRL_XOSC_ENABLE_Pos)) /* Assignment of value for ENABLE in the SYSCTRL_XOSC register */
#define SYSCTRL_XOSC_XTALEN_Pos               _UINT16_(2)                                          /* (SYSCTRL_XOSC) Crystal Oscillator Enable Position */
#define SYSCTRL_XOSC_XTALEN_Msk               (_UINT16_(0x1) << SYSCTRL_XOSC_XTALEN_Pos)           /* (SYSCTRL_XOSC) Crystal Oscillator Enable Mask */
#define SYSCTRL_XOSC_XTALEN(value)            (SYSCTRL_XOSC_XTALEN_Msk & (_UINT16_(value) << SYSCTRL_XOSC_XTALEN_Pos)) /* Assignment of value for XTALEN in the SYSCTRL_XOSC register */
#define SYSCTRL_XOSC_RUNSTDBY_Pos             _UINT16_(6)                                          /* (SYSCTRL_XOSC) Run in Standby Position */
#define SYSCTRL_XOSC_RUNSTDBY_Msk             (_UINT16_(0x1) << SYSCTRL_XOSC_RUNSTDBY_Pos)         /* (SYSCTRL_XOSC) Run in Standby Mask */
#define SYSCTRL_XOSC_RUNSTDBY(value)          (SYSCTRL_XOSC_RUNSTDBY_Msk & (_UINT16_(value) << SYSCTRL_XOSC_RUNSTDBY_Pos)) /* Assignment of value for RUNSTDBY in the SYSCTRL_XOSC register */
#define SYSCTRL_XOSC_ONDEMAND_Pos             _UINT16_(7)                                          /* (SYSCTRL_XOSC) On Demand Control Position */
#define SYSCTRL_XOSC_ONDEMAND_Msk             (_UINT16_(0x1) << SYSCTRL_XOSC_ONDEMAND_Pos)         /* (SYSCTRL_XOSC) On Demand Control Mask */
#define SYSCTRL_XOSC_ONDEMAND(value)          (SYSCTRL_XOSC_ONDEMAND_Msk & (_UINT16_(value) << SYSCTRL_XOSC_ONDEMAND_Pos)) /* Assignment of value for ONDEMAND in the SYSCTRL_XOSC register */
#define SYSCTRL_XOSC_GAIN_Pos                 _UINT16_(8)                                          /* (SYSCTRL_XOSC) Oscillator Gain Position */
#define SYSCTRL_XOSC_GAIN_Msk                 (_UINT16_(0x7) << SYSCTRL_XOSC_GAIN_Pos)             /* (SYSCTRL_XOSC) Oscillator Gain Mask */
#define SYSCTRL_XOSC_GAIN(value)              (SYSCTRL_XOSC_GAIN_Msk & (_UINT16_(value) << SYSCTRL_XOSC_GAIN_Pos)) /* Assignment of value for GAIN in the SYSCTRL_XOSC register */
#define   SYSCTRL_XOSC_GAIN_0_Val             _UINT16_(0x0)                                        /* (SYSCTRL_XOSC) 2MHz  */
#define   SYSCTRL_XOSC_GAIN_1_Val             _UINT16_(0x1)                                        /* (SYSCTRL_XOSC) 4MHz  */
#define   SYSCTRL_XOSC_GAIN_2_Val             _UINT16_(0x2)                                        /* (SYSCTRL_XOSC) 8MHz  */
#define   SYSCTRL_XOSC_GAIN_3_Val             _UINT16_(0x3)                                        /* (SYSCTRL_XOSC) 16MHz  */
#define   SYSCTRL_XOSC_GAIN_4_Val             _UINT16_(0x4)                                        /* (SYSCTRL_XOSC) 30MHz  */
#define SYSCTRL_XOSC_GAIN_0                   (SYSCTRL_XOSC_GAIN_0_Val << SYSCTRL_XOSC_GAIN_Pos)   /* (SYSCTRL_XOSC) 2MHz Position */
#define SYSCTRL_XOSC_GAIN_1                   (SYSCTRL_XOSC_GAIN_1_Val << SYSCTRL_XOSC_GAIN_Pos)   /* (SYSCTRL_XOSC) 4MHz Position */
#define SYSCTRL_XOSC_GAIN_2                   (SYSCTRL_XOSC_GAIN_2_Val << SYSCTRL_XOSC_GAIN_Pos)   /* (SYSCTRL_XOSC) 8MHz Position */
#define SYSCTRL_XOSC_GAIN_3                   (SYSCTRL_XOSC_GAIN_3_Val << SYSCTRL_XOSC_GAIN_Pos)   /* (SYSCTRL_XOSC) 16MHz Position */
#define SYSCTRL_XOSC_GAIN_4                   (SYSCTRL_XOSC_GAIN_4_Val << SYSCTRL_XOSC_GAIN_Pos)   /* (SYSCTRL_XOSC) 30MHz Position */
#define SYSCTRL_XOSC_AMPGC_Pos                _UINT16_(11)                                         /* (SYSCTRL_XOSC) Automatic Amplitude Gain Control Position */
#define SYSCTRL_XOSC_AMPGC_Msk                (_UINT16_(0x1) << SYSCTRL_XOSC_AMPGC_Pos)            /* (SYSCTRL_XOSC) Automatic Amplitude Gain Control Mask */
#define SYSCTRL_XOSC_AMPGC(value)             (SYSCTRL_XOSC_AMPGC_Msk & (_UINT16_(value) << SYSCTRL_XOSC_AMPGC_Pos)) /* Assignment of value for AMPGC in the SYSCTRL_XOSC register */
#define SYSCTRL_XOSC_STARTUP_Pos              _UINT16_(12)                                         /* (SYSCTRL_XOSC) Start-Up Time Position */
#define SYSCTRL_XOSC_STARTUP_Msk              (_UINT16_(0xF) << SYSCTRL_XOSC_STARTUP_Pos)          /* (SYSCTRL_XOSC) Start-Up Time Mask */
#define SYSCTRL_XOSC_STARTUP(value)           (SYSCTRL_XOSC_STARTUP_Msk & (_UINT16_(value) << SYSCTRL_XOSC_STARTUP_Pos)) /* Assignment of value for STARTUP in the SYSCTRL_XOSC register */
#define   SYSCTRL_XOSC_STARTUP_CYCLE1_Val     _UINT16_(0x0)                                        /* (SYSCTRL_XOSC) 31 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE2_Val     _UINT16_(0x1)                                        /* (SYSCTRL_XOSC) 61 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE4_Val     _UINT16_(0x2)                                        /* (SYSCTRL_XOSC) 122 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE8_Val     _UINT16_(0x3)                                        /* (SYSCTRL_XOSC) 244 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE16_Val    _UINT16_(0x4)                                        /* (SYSCTRL_XOSC) 488 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE32_Val    _UINT16_(0x5)                                        /* (SYSCTRL_XOSC) 977 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE64_Val    _UINT16_(0x6)                                        /* (SYSCTRL_XOSC) 1953 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE128_Val   _UINT16_(0x7)                                        /* (SYSCTRL_XOSC) 3906 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE256_Val   _UINT16_(0x8)                                        /* (SYSCTRL_XOSC) 7813 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE512_Val   _UINT16_(0x9)                                        /* (SYSCTRL_XOSC) 15625 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE1024_Val  _UINT16_(0xA)                                        /* (SYSCTRL_XOSC) 31250 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE2048_Val  _UINT16_(0xB)                                        /* (SYSCTRL_XOSC) 62500 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE4096_Val  _UINT16_(0xC)                                        /* (SYSCTRL_XOSC) 125000 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE8192_Val  _UINT16_(0xD)                                        /* (SYSCTRL_XOSC) 250000 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE16384_Val _UINT16_(0xE)                                        /* (SYSCTRL_XOSC) 500000 us  */
#define   SYSCTRL_XOSC_STARTUP_CYCLE32768_Val _UINT16_(0xF)                                        /* (SYSCTRL_XOSC) 1000000 us  */
#define SYSCTRL_XOSC_STARTUP_CYCLE1           (SYSCTRL_XOSC_STARTUP_CYCLE1_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 31 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE2           (SYSCTRL_XOSC_STARTUP_CYCLE2_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 61 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE4           (SYSCTRL_XOSC_STARTUP_CYCLE4_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 122 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE8           (SYSCTRL_XOSC_STARTUP_CYCLE8_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 244 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE16          (SYSCTRL_XOSC_STARTUP_CYCLE16_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 488 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE32          (SYSCTRL_XOSC_STARTUP_CYCLE32_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 977 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE64          (SYSCTRL_XOSC_STARTUP_CYCLE64_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 1953 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE128         (SYSCTRL_XOSC_STARTUP_CYCLE128_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 3906 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE256         (SYSCTRL_XOSC_STARTUP_CYCLE256_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 7813 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE512         (SYSCTRL_XOSC_STARTUP_CYCLE512_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 15625 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE1024        (SYSCTRL_XOSC_STARTUP_CYCLE1024_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 31250 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE2048        (SYSCTRL_XOSC_STARTUP_CYCLE2048_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 62500 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE4096        (SYSCTRL_XOSC_STARTUP_CYCLE4096_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 125000 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE8192        (SYSCTRL_XOSC_STARTUP_CYCLE8192_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 250000 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE16384       (SYSCTRL_XOSC_STARTUP_CYCLE16384_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 500000 us Position */
#define SYSCTRL_XOSC_STARTUP_CYCLE32768       (SYSCTRL_XOSC_STARTUP_CYCLE32768_Val << SYSCTRL_XOSC_STARTUP_Pos) /* (SYSCTRL_XOSC) 1000000 us Position */
#define SYSCTRL_XOSC_Msk                      _UINT16_(0xFFC6)                                     /* (SYSCTRL_XOSC) Register Mask  */


/* -------- SYSCTRL_XOSC32K : (SYSCTRL Offset: 0x14) (R/W 16) 32kHz External Crystal Oscillator (XOSC32K) Control -------- */
#define SYSCTRL_XOSC32K_RESETVALUE            _UINT16_(0x80)                                       /*  (SYSCTRL_XOSC32K) 32kHz External Crystal Oscillator (XOSC32K) Control  Reset Value */

#define SYSCTRL_XOSC32K_ENABLE_Pos            _UINT16_(1)                                          /* (SYSCTRL_XOSC32K) Oscillator Enable Position */
#define SYSCTRL_XOSC32K_ENABLE_Msk            (_UINT16_(0x1) << SYSCTRL_XOSC32K_ENABLE_Pos)        /* (SYSCTRL_XOSC32K) Oscillator Enable Mask */
#define SYSCTRL_XOSC32K_ENABLE(value)         (SYSCTRL_XOSC32K_ENABLE_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_ENABLE_Pos)) /* Assignment of value for ENABLE in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_XTALEN_Pos            _UINT16_(2)                                          /* (SYSCTRL_XOSC32K) Crystal Oscillator Enable Position */
#define SYSCTRL_XOSC32K_XTALEN_Msk            (_UINT16_(0x1) << SYSCTRL_XOSC32K_XTALEN_Pos)        /* (SYSCTRL_XOSC32K) Crystal Oscillator Enable Mask */
#define SYSCTRL_XOSC32K_XTALEN(value)         (SYSCTRL_XOSC32K_XTALEN_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_XTALEN_Pos)) /* Assignment of value for XTALEN in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_EN32K_Pos             _UINT16_(3)                                          /* (SYSCTRL_XOSC32K) 32kHz Output Enable Position */
#define SYSCTRL_XOSC32K_EN32K_Msk             (_UINT16_(0x1) << SYSCTRL_XOSC32K_EN32K_Pos)         /* (SYSCTRL_XOSC32K) 32kHz Output Enable Mask */
#define SYSCTRL_XOSC32K_EN32K(value)          (SYSCTRL_XOSC32K_EN32K_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_EN32K_Pos)) /* Assignment of value for EN32K in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_EN1K_Pos              _UINT16_(4)                                          /* (SYSCTRL_XOSC32K) 1kHz Output Enable Position */
#define SYSCTRL_XOSC32K_EN1K_Msk              (_UINT16_(0x1) << SYSCTRL_XOSC32K_EN1K_Pos)          /* (SYSCTRL_XOSC32K) 1kHz Output Enable Mask */
#define SYSCTRL_XOSC32K_EN1K(value)           (SYSCTRL_XOSC32K_EN1K_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_EN1K_Pos)) /* Assignment of value for EN1K in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_AAMPEN_Pos            _UINT16_(5)                                          /* (SYSCTRL_XOSC32K) Automatic Amplitude Control Enable Position */
#define SYSCTRL_XOSC32K_AAMPEN_Msk            (_UINT16_(0x1) << SYSCTRL_XOSC32K_AAMPEN_Pos)        /* (SYSCTRL_XOSC32K) Automatic Amplitude Control Enable Mask */
#define SYSCTRL_XOSC32K_AAMPEN(value)         (SYSCTRL_XOSC32K_AAMPEN_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_AAMPEN_Pos)) /* Assignment of value for AAMPEN in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_RUNSTDBY_Pos          _UINT16_(6)                                          /* (SYSCTRL_XOSC32K) Run in Standby Position */
#define SYSCTRL_XOSC32K_RUNSTDBY_Msk          (_UINT16_(0x1) << SYSCTRL_XOSC32K_RUNSTDBY_Pos)      /* (SYSCTRL_XOSC32K) Run in Standby Mask */
#define SYSCTRL_XOSC32K_RUNSTDBY(value)       (SYSCTRL_XOSC32K_RUNSTDBY_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_RUNSTDBY_Pos)) /* Assignment of value for RUNSTDBY in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_ONDEMAND_Pos          _UINT16_(7)                                          /* (SYSCTRL_XOSC32K) On Demand Control Position */
#define SYSCTRL_XOSC32K_ONDEMAND_Msk          (_UINT16_(0x1) << SYSCTRL_XOSC32K_ONDEMAND_Pos)      /* (SYSCTRL_XOSC32K) On Demand Control Mask */
#define SYSCTRL_XOSC32K_ONDEMAND(value)       (SYSCTRL_XOSC32K_ONDEMAND_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_ONDEMAND_Pos)) /* Assignment of value for ONDEMAND in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_STARTUP_Pos           _UINT16_(8)                                          /* (SYSCTRL_XOSC32K) Oscillator Start-Up Time Position */
#define SYSCTRL_XOSC32K_STARTUP_Msk           (_UINT16_(0x7) << SYSCTRL_XOSC32K_STARTUP_Pos)       /* (SYSCTRL_XOSC32K) Oscillator Start-Up Time Mask */
#define SYSCTRL_XOSC32K_STARTUP(value)        (SYSCTRL_XOSC32K_STARTUP_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_STARTUP_Pos)) /* Assignment of value for STARTUP in the SYSCTRL_XOSC32K register */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE1_Val  _UINT16_(0x0)                                        /* (SYSCTRL_XOSC32K) 0.122 ms  */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE32_Val _UINT16_(0x1)                                        /* (SYSCTRL_XOSC32K) 1.068 ms  */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE2048_Val _UINT16_(0x2)                                        /* (SYSCTRL_XOSC32K) 62.592 ms  */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE4096_Val _UINT16_(0x3)                                        /* (SYSCTRL_XOSC32K) 125.092 ms  */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE16384_Val _UINT16_(0x4)                                        /* (SYSCTRL_XOSC32K) 500.092 ms  */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE32768_Val _UINT16_(0x5)                                        /* (SYSCTRL_XOSC32K) 1000.092 ms  */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE65536_Val _UINT16_(0x6)                                        /* (SYSCTRL_XOSC32K) 2000.092 ms  */
#define   SYSCTRL_XOSC32K_STARTUP_CYCLE131072_Val _UINT16_(0x7)                                        /* (SYSCTRL_XOSC32K) 4000.092 ms  */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE1        (SYSCTRL_XOSC32K_STARTUP_CYCLE1_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 0.122 ms Position */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE32       (SYSCTRL_XOSC32K_STARTUP_CYCLE32_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 1.068 ms Position */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE2048     (SYSCTRL_XOSC32K_STARTUP_CYCLE2048_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 62.592 ms Position */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE4096     (SYSCTRL_XOSC32K_STARTUP_CYCLE4096_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 125.092 ms Position */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE16384    (SYSCTRL_XOSC32K_STARTUP_CYCLE16384_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 500.092 ms Position */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE32768    (SYSCTRL_XOSC32K_STARTUP_CYCLE32768_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 1000.092 ms Position */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE65536    (SYSCTRL_XOSC32K_STARTUP_CYCLE65536_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 2000.092 ms Position */
#define SYSCTRL_XOSC32K_STARTUP_CYCLE131072   (SYSCTRL_XOSC32K_STARTUP_CYCLE131072_Val << SYSCTRL_XOSC32K_STARTUP_Pos) /* (SYSCTRL_XOSC32K) 4000.092 ms Position */
#define SYSCTRL_XOSC32K_WRTLOCK_Pos           _UINT16_(12)                                         /* (SYSCTRL_XOSC32K) Write Lock Position */
#define SYSCTRL_XOSC32K_WRTLOCK_Msk           (_UINT16_(0x1) << SYSCTRL_XOSC32K_WRTLOCK_Pos)       /* (SYSCTRL_XOSC32K) Write Lock Mask */
#define SYSCTRL_XOSC32K_WRTLOCK(value)        (SYSCTRL_XOSC32K_WRTLOCK_Msk & (_UINT16_(value) << SYSCTRL_XOSC32K_WRTLOCK_Pos)) /* Assignment of value for WRTLOCK in the SYSCTRL_XOSC32K register */
#define SYSCTRL_XOSC32K_Msk                   _UINT16_(0x17FE)                                     /* (SYSCTRL_XOSC32K) Register Mask  */


/* -------- SYSCTRL_OSC32K : (SYSCTRL Offset: 0x18) (R/W 32) 32kHz Internal Oscillator (OSC32K) Control -------- */
#define SYSCTRL_OSC32K_RESETVALUE             _UINT32_(0x3F0080)                                   /*  (SYSCTRL_OSC32K) 32kHz Internal Oscillator (OSC32K) Control  Reset Value */

#define SYSCTRL_OSC32K_ENABLE_Pos             _UINT32_(1)                                          /* (SYSCTRL_OSC32K) Oscillator Enable Position */
#define SYSCTRL_OSC32K_ENABLE_Msk             (_UINT32_(0x1) << SYSCTRL_OSC32K_ENABLE_Pos)         /* (SYSCTRL_OSC32K) Oscillator Enable Mask */
#define SYSCTRL_OSC32K_ENABLE(value)          (SYSCTRL_OSC32K_ENABLE_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_ENABLE_Pos)) /* Assignment of value for ENABLE in the SYSCTRL_OSC32K register */
#define SYSCTRL_OSC32K_EN32K_Pos              _UINT32_(2)                                          /* (SYSCTRL_OSC32K) 32kHz Output Enable Position */
#define SYSCTRL_OSC32K_EN32K_Msk              (_UINT32_(0x1) << SYSCTRL_OSC32K_EN32K_Pos)          /* (SYSCTRL_OSC32K) 32kHz Output Enable Mask */
#define SYSCTRL_OSC32K_EN32K(value)           (SYSCTRL_OSC32K_EN32K_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_EN32K_Pos)) /* Assignment of value for EN32K in the SYSCTRL_OSC32K register */
#define SYSCTRL_OSC32K_EN1K_Pos               _UINT32_(3)                                          /* (SYSCTRL_OSC32K) 1kHz Output Enable Position */
#define SYSCTRL_OSC32K_EN1K_Msk               (_UINT32_(0x1) << SYSCTRL_OSC32K_EN1K_Pos)           /* (SYSCTRL_OSC32K) 1kHz Output Enable Mask */
#define SYSCTRL_OSC32K_EN1K(value)            (SYSCTRL_OSC32K_EN1K_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_EN1K_Pos)) /* Assignment of value for EN1K in the SYSCTRL_OSC32K register */
#define SYSCTRL_OSC32K_RUNSTDBY_Pos           _UINT32_(6)                                          /* (SYSCTRL_OSC32K) Run in Standby Position */
#define SYSCTRL_OSC32K_RUNSTDBY_Msk           (_UINT32_(0x1) << SYSCTRL_OSC32K_RUNSTDBY_Pos)       /* (SYSCTRL_OSC32K) Run in Standby Mask */
#define SYSCTRL_OSC32K_RUNSTDBY(value)        (SYSCTRL_OSC32K_RUNSTDBY_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_RUNSTDBY_Pos)) /* Assignment of value for RUNSTDBY in the SYSCTRL_OSC32K register */
#define SYSCTRL_OSC32K_ONDEMAND_Pos           _UINT32_(7)                                          /* (SYSCTRL_OSC32K) On Demand Control Position */
#define SYSCTRL_OSC32K_ONDEMAND_Msk           (_UINT32_(0x1) << SYSCTRL_OSC32K_ONDEMAND_Pos)       /* (SYSCTRL_OSC32K) On Demand Control Mask */
#define SYSCTRL_OSC32K_ONDEMAND(value)        (SYSCTRL_OSC32K_ONDEMAND_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_ONDEMAND_Pos)) /* Assignment of value for ONDEMAND in the SYSCTRL_OSC32K register */
#define SYSCTRL_OSC32K_STARTUP_Pos            _UINT32_(8)                                          /* (SYSCTRL_OSC32K) Oscillator Start-Up Time Position */
#define SYSCTRL_OSC32K_STARTUP_Msk            (_UINT32_(0x7) << SYSCTRL_OSC32K_STARTUP_Pos)        /* (SYSCTRL_OSC32K) Oscillator Start-Up Time Mask */
#define SYSCTRL_OSC32K_STARTUP(value)         (SYSCTRL_OSC32K_STARTUP_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_STARTUP_Pos)) /* Assignment of value for STARTUP in the SYSCTRL_OSC32K register */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE3_Val   _UINT32_(0x0)                                        /* (SYSCTRL_OSC32K) 0.092 ms  */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE4_Val   _UINT32_(0x1)                                        /* (SYSCTRL_OSC32K) 0.122 ms  */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE6_Val   _UINT32_(0x2)                                        /* (SYSCTRL_OSC32K) 0.183 ms  */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE10_Val  _UINT32_(0x3)                                        /* (SYSCTRL_OSC32K) 0.305 ms  */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE18_Val  _UINT32_(0x4)                                        /* (SYSCTRL_OSC32K) 0.549 ms  */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE34_Val  _UINT32_(0x5)                                        /* (SYSCTRL_OSC32K) 1.038 ms  */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE66_Val  _UINT32_(0x6)                                        /* (SYSCTRL_OSC32K) 2.014 ms  */
#define   SYSCTRL_OSC32K_STARTUP_CYCLE130_Val _UINT32_(0x7)                                        /* (SYSCTRL_OSC32K) 3.967 ms  */
#define SYSCTRL_OSC32K_STARTUP_CYCLE3         (SYSCTRL_OSC32K_STARTUP_CYCLE3_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 0.092 ms Position */
#define SYSCTRL_OSC32K_STARTUP_CYCLE4         (SYSCTRL_OSC32K_STARTUP_CYCLE4_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 0.122 ms Position */
#define SYSCTRL_OSC32K_STARTUP_CYCLE6         (SYSCTRL_OSC32K_STARTUP_CYCLE6_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 0.183 ms Position */
#define SYSCTRL_OSC32K_STARTUP_CYCLE10        (SYSCTRL_OSC32K_STARTUP_CYCLE10_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 0.305 ms Position */
#define SYSCTRL_OSC32K_STARTUP_CYCLE18        (SYSCTRL_OSC32K_STARTUP_CYCLE18_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 0.549 ms Position */
#define SYSCTRL_OSC32K_STARTUP_CYCLE34        (SYSCTRL_OSC32K_STARTUP_CYCLE34_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 1.038 ms Position */
#define SYSCTRL_OSC32K_STARTUP_CYCLE66        (SYSCTRL_OSC32K_STARTUP_CYCLE66_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 2.014 ms Position */
#define SYSCTRL_OSC32K_STARTUP_CYCLE130       (SYSCTRL_OSC32K_STARTUP_CYCLE130_Val << SYSCTRL_OSC32K_STARTUP_Pos) /* (SYSCTRL_OSC32K) 3.967 ms Position */
#define SYSCTRL_OSC32K_WRTLOCK_Pos            _UINT32_(12)                                         /* (SYSCTRL_OSC32K) Write Lock Position */
#define SYSCTRL_OSC32K_WRTLOCK_Msk            (_UINT32_(0x1) << SYSCTRL_OSC32K_WRTLOCK_Pos)        /* (SYSCTRL_OSC32K) Write Lock Mask */
#define SYSCTRL_OSC32K_WRTLOCK(value)         (SYSCTRL_OSC32K_WRTLOCK_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_WRTLOCK_Pos)) /* Assignment of value for WRTLOCK in the SYSCTRL_OSC32K register */
#define SYSCTRL_OSC32K_CALIB_Pos              _UINT32_(16)                                         /* (SYSCTRL_OSC32K) Oscillator Calibration Position */
#define SYSCTRL_OSC32K_CALIB_Msk              (_UINT32_(0x7F) << SYSCTRL_OSC32K_CALIB_Pos)         /* (SYSCTRL_OSC32K) Oscillator Calibration Mask */
#define SYSCTRL_OSC32K_CALIB(value)           (SYSCTRL_OSC32K_CALIB_Msk & (_UINT32_(value) << SYSCTRL_OSC32K_CALIB_Pos)) /* Assignment of value for CALIB in the SYSCTRL_OSC32K register */
#define SYSCTRL_OSC32K_Msk                    _UINT32_(0x007F17CE)                                 /* (SYSCTRL_OSC32K) Register Mask  */


/* -------- SYSCTRL_OSCULP32K : (SYSCTRL Offset: 0x1C) (R/W 8) OSCULP32K Control -------- */
#define SYSCTRL_OSCULP32K_RESETVALUE          _UINT8_(0x0F)                                        /*  (SYSCTRL_OSCULP32K) OSCULP32K Control  Reset Value */

#define SYSCTRL_OSCULP32K_CALIB_Pos           _UINT8_(0)                                           /* (SYSCTRL_OSCULP32K) Calibration Value Position */
#define SYSCTRL_OSCULP32K_CALIB_Msk           (_UINT8_(0x1F) << SYSCTRL_OSCULP32K_CALIB_Pos)       /* (SYSCTRL_OSCULP32K) Calibration Value Mask */
#define SYSCTRL_OSCULP32K_CALIB(value)        (SYSCTRL_OSCULP32K_CALIB_Msk & (_UINT8_(value) << SYSCTRL_OSCULP32K_CALIB_Pos)) /* Assignment of value for CALIB in the SYSCTRL_OSCULP32K register */
#define SYSCTRL_OSCULP32K_WRTLOCK_Pos         _UINT8_(7)                                           /* (SYSCTRL_OSCULP32K) Write Lock Position */
#define SYSCTRL_OSCULP32K_WRTLOCK_Msk         (_UINT8_(0x1) << SYSCTRL_OSCULP32K_WRTLOCK_Pos)      /* (SYSCTRL_OSCULP32K) Write Lock Mask */
#define SYSCTRL_OSCULP32K_WRTLOCK(value)      (SYSCTRL_OSCULP32K_WRTLOCK_Msk & (_UINT8_(value) << SYSCTRL_OSCULP32K_WRTLOCK_Pos)) /* Assignment of value for WRTLOCK in the SYSCTRL_OSCULP32K register */
#define SYSCTRL_OSCULP32K_Msk                 _UINT8_(0x9F)                                        /* (SYSCTRL_OSCULP32K) Register Mask  */


/* -------- SYSCTRL_OSC8M : (SYSCTRL Offset: 0x20) (R/W 32) 8MHz Internal Oscillator (OSC8M) Control -------- */
#define SYSCTRL_OSC8M_RESETVALUE              _UINT32_(0x87070382)                                 /*  (SYSCTRL_OSC8M) 8MHz Internal Oscillator (OSC8M) Control  Reset Value */

#define SYSCTRL_OSC8M_ENABLE_Pos              _UINT32_(1)                                          /* (SYSCTRL_OSC8M) Oscillator Enable Position */
#define SYSCTRL_OSC8M_ENABLE_Msk              (_UINT32_(0x1) << SYSCTRL_OSC8M_ENABLE_Pos)          /* (SYSCTRL_OSC8M) Oscillator Enable Mask */
#define SYSCTRL_OSC8M_ENABLE(value)           (SYSCTRL_OSC8M_ENABLE_Msk & (_UINT32_(value) << SYSCTRL_OSC8M_ENABLE_Pos)) /* Assignment of value for ENABLE in the SYSCTRL_OSC8M register */
#define SYSCTRL_OSC8M_RUNSTDBY_Pos            _UINT32_(6)                                          /* (SYSCTRL_OSC8M) Run in Standby Position */
#define SYSCTRL_OSC8M_RUNSTDBY_Msk            (_UINT32_(0x1) << SYSCTRL_OSC8M_RUNSTDBY_Pos)        /* (SYSCTRL_OSC8M) Run in Standby Mask */
#define SYSCTRL_OSC8M_RUNSTDBY(value)         (SYSCTRL_OSC8M_RUNSTDBY_Msk & (_UINT32_(value) << SYSCTRL_OSC8M_RUNSTDBY_Pos)) /* Assignment of value for RUNSTDBY in the SYSCTRL_OSC8M register */
#define SYSCTRL_OSC8M_ONDEMAND_Pos            _UINT32_(7)                                          /* (SYSCTRL_OSC8M) On Demand Control Position */
#define SYSCTRL_OSC8M_ONDEMAND_Msk            (_UINT32_(0x1) << SYSCTRL_OSC8M_ONDEMAND_Pos)        /* (SYSCTRL_OSC8M) On Demand Control Mask */
#define SYSCTRL_OSC8M_ONDEMAND(value)         (SYSCTRL_OSC8M_ONDEMAND_Msk & (_UINT32_(value) << SYSCTRL_OSC8M_ONDEMAND_Pos)) /* Assignment of value for ONDEMAND in the SYSCTRL_OSC8M register */
#define SYSCTRL_OSC8M_PRESC_Pos               _UINT32_(8)                                          /* (SYSCTRL_OSC8M) Oscillator Prescaler Position */
#define SYSCTRL_OSC8M_PRESC_Msk               (_UINT32_(0x3) << SYSCTRL_OSC8M_PRESC_Pos)           /* (SYSCTRL_OSC8M) Oscillator Prescaler Mask */
#define SYSCTRL_OSC8M_PRESC(value)            (SYSCTRL_OSC8M_PRESC_Msk & (_UINT32_(value) << SYSCTRL_OSC8M_PRESC_Pos)) /* Assignment of value for PRESC in the SYSCTRL_OSC8M register */
#define   SYSCTRL_OSC8M_PRESC_0_Val           _UINT32_(0x0)                                        /* (SYSCTRL_OSC8M) 1  */
#define   SYSCTRL_OSC8M_PRESC_1_Val           _UINT32_(0x1)                                        /* (SYSCTRL_OSC8M) 2  */
#define   SYSCTRL_OSC8M_PRESC_2_Val           _UINT32_(0x2)                                        /* (SYSCTRL_OSC8M) 4  */
#define   SYSCTRL_OSC8M_PRESC_3_Val           _UINT32_(0x3)                                        /* (SYSCTRL_OSC8M) 8  */
#define SYSCTRL_OSC8M_PRESC_0                 (SYSCTRL_OSC8M_PRESC_0_Val << SYSCTRL_OSC8M_PRESC_Pos) /* (SYSCTRL_OSC8M) 1 Position */
#define SYSCTRL_OSC8M_PRESC_1                 (SYSCTRL_OSC8M_PRESC_1_Val << SYSCTRL_OSC8M_PRESC_Pos) /* (SYSCTRL_OSC8M) 2 Position */
#define SYSCTRL_OSC8M_PRESC_2                 (SYSCTRL_OSC8M_PRESC_2_Val << SYSCTRL_OSC8M_PRESC_Pos) /* (SYSCTRL_OSC8M) 4 Position */
#define SYSCTRL_OSC8M_PRESC_3                 (SYSCTRL_OSC8M_PRESC_3_Val << SYSCTRL_OSC8M_PRESC_Pos) /* (SYSCTRL_OSC8M) 8 Position */
#define SYSCTRL_OSC8M_CALIB_Pos               _UINT32_(16)                                         /* (SYSCTRL_OSC8M) Oscillator Calibration Position */
#define SYSCTRL_OSC8M_CALIB_Msk               (_UINT32_(0xFFF) << SYSCTRL_OSC8M_CALIB_Pos)         /* (SYSCTRL_OSC8M) Oscillator Calibration Mask */
#define SYSCTRL_OSC8M_CALIB(value)            (SYSCTRL_OSC8M_CALIB_Msk & (_UINT32_(value) << SYSCTRL_OSC8M_CALIB_Pos)) /* Assignment of value for CALIB in the SYSCTRL_OSC8M register */
#define SYSCTRL_OSC8M_FRANGE_Pos              _UINT32_(30)                                         /* (SYSCTRL_OSC8M) Oscillator Frequency Range Position */
#define SYSCTRL_OSC8M_FRANGE_Msk              (_UINT32_(0x3) << SYSCTRL_OSC8M_FRANGE_Pos)          /* (SYSCTRL_OSC8M) Oscillator Frequency Range Mask */
#define SYSCTRL_OSC8M_FRANGE(value)           (SYSCTRL_OSC8M_FRANGE_Msk & (_UINT32_(value) << SYSCTRL_OSC8M_FRANGE_Pos)) /* Assignment of value for FRANGE in the SYSCTRL_OSC8M register */
#define   SYSCTRL_OSC8M_FRANGE_0_Val          _UINT32_(0x0)                                        /* (SYSCTRL_OSC8M) 4 to 6MHz  */
#define   SYSCTRL_OSC8M_FRANGE_1_Val          _UINT32_(0x1)                                        /* (SYSCTRL_OSC8M) 6 to 8MHz  */
#define   SYSCTRL_OSC8M_FRANGE_2_Val          _UINT32_(0x2)                                        /* (SYSCTRL_OSC8M) 8 to 11MHz  */
#define   SYSCTRL_OSC8M_FRANGE_3_Val          _UINT32_(0x3)                                        /* (SYSCTRL_OSC8M) 11 to 15MHz  */
#define SYSCTRL_OSC8M_FRANGE_0                (SYSCTRL_OSC8M_FRANGE_0_Val << SYSCTRL_OSC8M_FRANGE_Pos) /* (SYSCTRL_OSC8M) 4 to 6MHz Position */
#define SYSCTRL_OSC8M_FRANGE_1                (SYSCTRL_OSC8M_FRANGE_1_Val << SYSCTRL_OSC8M_FRANGE_Pos) /* (SYSCTRL_OSC8M) 6 to 8MHz Position */
#define SYSCTRL_OSC8M_FRANGE_2                (SYSCTRL_OSC8M_FRANGE_2_Val << SYSCTRL_OSC8M_FRANGE_Pos) /* (SYSCTRL_OSC8M) 8 to 11MHz Position */
#define SYSCTRL_OSC8M_FRANGE_3                (SYSCTRL_OSC8M_FRANGE_3_Val << SYSCTRL_OSC8M_FRANGE_Pos) /* (SYSCTRL_OSC8M) 11 to 15MHz Position */
#define SYSCTRL_OSC8M_Msk                     _UINT32_(0xCFFF03C2)                                 /* (SYSCTRL_OSC8M) Register Mask  */


/* -------- SYSCTRL_DFLLCTRL : (SYSCTRL Offset: 0x24) (R/W 16) DFLL Config -------- */
#define SYSCTRL_DFLLCTRL_RESETVALUE           _UINT16_(0x80)                                       /*  (SYSCTRL_DFLLCTRL) DFLL Config  Reset Value */

#define SYSCTRL_DFLLCTRL_ENABLE_Pos           _UINT16_(1)                                          /* (SYSCTRL_DFLLCTRL) Enable Position */
#define SYSCTRL_DFLLCTRL_ENABLE_Msk           (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_ENABLE_Pos)       /* (SYSCTRL_DFLLCTRL) Enable Mask */
#define SYSCTRL_DFLLCTRL_ENABLE(value)        (SYSCTRL_DFLLCTRL_ENABLE_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_ENABLE_Pos)) /* Assignment of value for ENABLE in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_MODE_Pos             _UINT16_(2)                                          /* (SYSCTRL_DFLLCTRL) Mode Selection Position */
#define SYSCTRL_DFLLCTRL_MODE_Msk             (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_MODE_Pos)         /* (SYSCTRL_DFLLCTRL) Mode Selection Mask */
#define SYSCTRL_DFLLCTRL_MODE(value)          (SYSCTRL_DFLLCTRL_MODE_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_MODE_Pos)) /* Assignment of value for MODE in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_STABLE_Pos           _UINT16_(3)                                          /* (SYSCTRL_DFLLCTRL) Stable Frequency Position */
#define SYSCTRL_DFLLCTRL_STABLE_Msk           (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_STABLE_Pos)       /* (SYSCTRL_DFLLCTRL) Stable Frequency Mask */
#define SYSCTRL_DFLLCTRL_STABLE(value)        (SYSCTRL_DFLLCTRL_STABLE_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_STABLE_Pos)) /* Assignment of value for STABLE in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_LLAW_Pos             _UINT16_(4)                                          /* (SYSCTRL_DFLLCTRL) Lose Lock After Wake Position */
#define SYSCTRL_DFLLCTRL_LLAW_Msk             (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_LLAW_Pos)         /* (SYSCTRL_DFLLCTRL) Lose Lock After Wake Mask */
#define SYSCTRL_DFLLCTRL_LLAW(value)          (SYSCTRL_DFLLCTRL_LLAW_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_LLAW_Pos)) /* Assignment of value for LLAW in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_RUNSTDBY_Pos         _UINT16_(6)                                          /* (SYSCTRL_DFLLCTRL) Run during Standby Position */
#define SYSCTRL_DFLLCTRL_RUNSTDBY_Msk         (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_RUNSTDBY_Pos)     /* (SYSCTRL_DFLLCTRL) Run during Standby Mask */
#define SYSCTRL_DFLLCTRL_RUNSTDBY(value)      (SYSCTRL_DFLLCTRL_RUNSTDBY_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_RUNSTDBY_Pos)) /* Assignment of value for RUNSTDBY in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_ONDEMAND_Pos         _UINT16_(7)                                          /* (SYSCTRL_DFLLCTRL) Enable on Demand Position */
#define SYSCTRL_DFLLCTRL_ONDEMAND_Msk         (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_ONDEMAND_Pos)     /* (SYSCTRL_DFLLCTRL) Enable on Demand Mask */
#define SYSCTRL_DFLLCTRL_ONDEMAND(value)      (SYSCTRL_DFLLCTRL_ONDEMAND_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_ONDEMAND_Pos)) /* Assignment of value for ONDEMAND in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_CCDIS_Pos            _UINT16_(8)                                          /* (SYSCTRL_DFLLCTRL) Chill Cycle Disable Position */
#define SYSCTRL_DFLLCTRL_CCDIS_Msk            (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_CCDIS_Pos)        /* (SYSCTRL_DFLLCTRL) Chill Cycle Disable Mask */
#define SYSCTRL_DFLLCTRL_CCDIS(value)         (SYSCTRL_DFLLCTRL_CCDIS_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_CCDIS_Pos)) /* Assignment of value for CCDIS in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_QLDIS_Pos            _UINT16_(9)                                          /* (SYSCTRL_DFLLCTRL) Quick Lock Disable Position */
#define SYSCTRL_DFLLCTRL_QLDIS_Msk            (_UINT16_(0x1) << SYSCTRL_DFLLCTRL_QLDIS_Pos)        /* (SYSCTRL_DFLLCTRL) Quick Lock Disable Mask */
#define SYSCTRL_DFLLCTRL_QLDIS(value)         (SYSCTRL_DFLLCTRL_QLDIS_Msk & (_UINT16_(value) << SYSCTRL_DFLLCTRL_QLDIS_Pos)) /* Assignment of value for QLDIS in the SYSCTRL_DFLLCTRL register */
#define SYSCTRL_DFLLCTRL_Msk                  _UINT16_(0x03DE)                                     /* (SYSCTRL_DFLLCTRL) Register Mask  */


/* -------- SYSCTRL_DFLLVAL : (SYSCTRL Offset: 0x28) (R/W 32) DFLL Calibration Value -------- */
#define SYSCTRL_DFLLVAL_RESETVALUE            _UINT32_(0x00)                                       /*  (SYSCTRL_DFLLVAL) DFLL Calibration Value  Reset Value */

#define SYSCTRL_DFLLVAL_FINE_Pos              _UINT32_(0)                                          /* (SYSCTRL_DFLLVAL) Fine Calibration Value Position */
#define SYSCTRL_DFLLVAL_FINE_Msk              (_UINT32_(0x3FF) << SYSCTRL_DFLLVAL_FINE_Pos)        /* (SYSCTRL_DFLLVAL) Fine Calibration Value Mask */
#define SYSCTRL_DFLLVAL_FINE(value)           (SYSCTRL_DFLLVAL_FINE_Msk & (_UINT32_(value) << SYSCTRL_DFLLVAL_FINE_Pos)) /* Assignment of value for FINE in the SYSCTRL_DFLLVAL register */
#define SYSCTRL_DFLLVAL_COARSE_Pos            _UINT32_(10)                                         /* (SYSCTRL_DFLLVAL) Coarse Calibration Value Position */
#define SYSCTRL_DFLLVAL_COARSE_Msk            (_UINT32_(0x3F) << SYSCTRL_DFLLVAL_COARSE_Pos)       /* (SYSCTRL_DFLLVAL) Coarse Calibration Value Mask */
#define SYSCTRL_DFLLVAL_COARSE(value)         (SYSCTRL_DFLLVAL_COARSE_Msk & (_UINT32_(value) << SYSCTRL_DFLLVAL_COARSE_Pos)) /* Assignment of value for COARSE in the SYSCTRL_DFLLVAL register */
#define SYSCTRL_DFLLVAL_DIFF_Pos              _UINT32_(16)                                         /* (SYSCTRL_DFLLVAL) Multiplication Ratio Difference Position */
#define SYSCTRL_DFLLVAL_DIFF_Msk              (_UINT32_(0xFFFF) << SYSCTRL_DFLLVAL_DIFF_Pos)       /* (SYSCTRL_DFLLVAL) Multiplication Ratio Difference Mask */
#define SYSCTRL_DFLLVAL_DIFF(value)           (SYSCTRL_DFLLVAL_DIFF_Msk & (_UINT32_(value) << SYSCTRL_DFLLVAL_DIFF_Pos)) /* Assignment of value for DIFF in the SYSCTRL_DFLLVAL register */
#define SYSCTRL_DFLLVAL_Msk                   _UINT32_(0xFFFFFFFF)                                 /* (SYSCTRL_DFLLVAL) Register Mask  */


/* -------- SYSCTRL_DFLLMUL : (SYSCTRL Offset: 0x2C) (R/W 32) DFLL Multiplier -------- */
#define SYSCTRL_DFLLMUL_RESETVALUE            _UINT32_(0x00)                                       /*  (SYSCTRL_DFLLMUL) DFLL Multiplier  Reset Value */

#define SYSCTRL_DFLLMUL_MUL_Pos               _UINT32_(0)                                          /* (SYSCTRL_DFLLMUL) Multiplication Value Position */
#define SYSCTRL_DFLLMUL_MUL_Msk               (_UINT32_(0xFFFF) << SYSCTRL_DFLLMUL_MUL_Pos)        /* (SYSCTRL_DFLLMUL) Multiplication Value Mask */
#define SYSCTRL_DFLLMUL_MUL(value)            (SYSCTRL_DFLLMUL_MUL_Msk & (_UINT32_(value) << SYSCTRL_DFLLMUL_MUL_Pos)) /* Assignment of value for MUL in the SYSCTRL_DFLLMUL register */
#define SYSCTRL_DFLLMUL_FSTEP_Pos             _UINT32_(16)                                         /* (SYSCTRL_DFLLMUL) Maximum Fine Step Size Position */
#define SYSCTRL_DFLLMUL_FSTEP_Msk             (_UINT32_(0x3FF) << SYSCTRL_DFLLMUL_FSTEP_Pos)       /* (SYSCTRL_DFLLMUL) Maximum Fine Step Size Mask */
#define SYSCTRL_DFLLMUL_FSTEP(value)          (SYSCTRL_DFLLMUL_FSTEP_Msk & (_UINT32_(value) << SYSCTRL_DFLLMUL_FSTEP_Pos)) /* Assignment of value for FSTEP in the SYSCTRL_DFLLMUL register */
#define SYSCTRL_DFLLMUL_CSTEP_Pos             _UINT32_(26)                                         /* (SYSCTRL_DFLLMUL) Maximum Coarse Step Size Position */
#define SYSCTRL_DFLLMUL_CSTEP_Msk             (_UINT32_(0x3F) << SYSCTRL_DFLLMUL_CSTEP_Pos)        /* (SYSCTRL_DFLLMUL) Maximum Coarse Step Size Mask */
#define SYSCTRL_DFLLMUL_CSTEP(value)          (SYSCTRL_DFLLMUL_CSTEP_Msk & (_UINT32_(value) << SYSCTRL_DFLLMUL_CSTEP_Pos)) /* Assignment of value for CSTEP in the SYSCTRL_DFLLMUL register */
#define SYSCTRL_DFLLMUL_Msk                   _UINT32_(0xFFFFFFFF)                                 /* (SYSCTRL_DFLLMUL) Register Mask  */


/* -------- SYSCTRL_DFLLSYNC : (SYSCTRL Offset: 0x30) (R/W 8) DFLL Synchronization -------- */
#define SYSCTRL_DFLLSYNC_RESETVALUE           _UINT8_(0x00)                                        /*  (SYSCTRL_DFLLSYNC) DFLL Synchronization  Reset Value */

#define SYSCTRL_DFLLSYNC_READREQ_Pos          _UINT8_(7)                                           /* (SYSCTRL_DFLLSYNC) Read Request Synchronization Position */
#define SYSCTRL_DFLLSYNC_READREQ_Msk          (_UINT8_(0x1) << SYSCTRL_DFLLSYNC_READREQ_Pos)       /* (SYSCTRL_DFLLSYNC) Read Request Synchronization Mask */
#define SYSCTRL_DFLLSYNC_READREQ(value)       (SYSCTRL_DFLLSYNC_READREQ_Msk & (_UINT8_(value) << SYSCTRL_DFLLSYNC_READREQ_Pos)) /* Assignment of value for READREQ in the SYSCTRL_DFLLSYNC register */
#define SYSCTRL_DFLLSYNC_Msk                  _UINT8_(0x80)                                        /* (SYSCTRL_DFLLSYNC) Register Mask  */


/* -------- SYSCTRL_BOD33 : (SYSCTRL Offset: 0x34) (R/W 32) 3.3V Brown-Out Detector (BOD33) Control -------- */
#define SYSCTRL_BOD33_RESETVALUE              _UINT32_(0x00)                                       /*  (SYSCTRL_BOD33) 3.3V Brown-Out Detector (BOD33) Control  Reset Value */

#define SYSCTRL_BOD33_ENABLE_Pos              _UINT32_(1)                                          /* (SYSCTRL_BOD33) Enable Position */
#define SYSCTRL_BOD33_ENABLE_Msk              (_UINT32_(0x1) << SYSCTRL_BOD33_ENABLE_Pos)          /* (SYSCTRL_BOD33) Enable Mask */
#define SYSCTRL_BOD33_ENABLE(value)           (SYSCTRL_BOD33_ENABLE_Msk & (_UINT32_(value) << SYSCTRL_BOD33_ENABLE_Pos)) /* Assignment of value for ENABLE in the SYSCTRL_BOD33 register */
#define SYSCTRL_BOD33_HYST_Pos                _UINT32_(2)                                          /* (SYSCTRL_BOD33) Hysteresis Enable Position */
#define SYSCTRL_BOD33_HYST_Msk                (_UINT32_(0x1) << SYSCTRL_BOD33_HYST_Pos)            /* (SYSCTRL_BOD33) Hysteresis Enable Mask */
#define SYSCTRL_BOD33_HYST(value)             (SYSCTRL_BOD33_HYST_Msk & (_UINT32_(value) << SYSCTRL_BOD33_HYST_Pos)) /* Assignment of value for HYST in the SYSCTRL_BOD33 register */
#define SYSCTRL_BOD33_ACTION_Pos              _UINT32_(3)                                          /* (SYSCTRL_BOD33) Action when Threshold Crossed Position */
#define SYSCTRL_BOD33_ACTION_Msk              (_UINT32_(0x3) << SYSCTRL_BOD33_ACTION_Pos)          /* (SYSCTRL_BOD33) Action when Threshold Crossed Mask */
#define SYSCTRL_BOD33_ACTION(value)           (SYSCTRL_BOD33_ACTION_Msk & (_UINT32_(value) << SYSCTRL_BOD33_ACTION_Pos)) /* Assignment of value for ACTION in the SYSCTRL_BOD33 register */
#define   SYSCTRL_BOD33_ACTION_NONE_Val       _UINT32_(0x0)                                        /* (SYSCTRL_BOD33) No action  */
#define   SYSCTRL_BOD33_ACTION_RESET_Val      _UINT32_(0x1)                                        /* (SYSCTRL_BOD33) The BODVDD generates a reset  */
#define   SYSCTRL_BOD33_ACTION_INT_Val        _UINT32_(0x2)                                        /* (SYSCTRL_BOD33) The BODVDD generates an interrupt  */
#define SYSCTRL_BOD33_ACTION_NONE             (SYSCTRL_BOD33_ACTION_NONE_Val << SYSCTRL_BOD33_ACTION_Pos) /* (SYSCTRL_BOD33) No action Position */
#define SYSCTRL_BOD33_ACTION_RESET            (SYSCTRL_BOD33_ACTION_RESET_Val << SYSCTRL_BOD33_ACTION_Pos) /* (SYSCTRL_BOD33) The BODVDD generates a reset Position */
#define SYSCTRL_BOD33_ACTION_INT              (SYSCTRL_BOD33_ACTION_INT_Val << SYSCTRL_BOD33_ACTION_Pos) /* (SYSCTRL_BOD33) The BODVDD generates an interrupt Position */
#define SYSCTRL_BOD33_RUNSTDBY_Pos            _UINT32_(6)                                          /* (SYSCTRL_BOD33) Run during Standby Position */
#define SYSCTRL_BOD33_RUNSTDBY_Msk            (_UINT32_(0x1) << SYSCTRL_BOD33_RUNSTDBY_Pos)        /* (SYSCTRL_BOD33) Run during Standby Mask */
#define SYSCTRL_BOD33_RUNSTDBY(value)         (SYSCTRL_BOD33_RUNSTDBY_Msk & (_UINT32_(value) << SYSCTRL_BOD33_RUNSTDBY_Pos)) /* Assignment of value for RUNSTDBY in the SYSCTRL_BOD33 register */
#define SYSCTRL_BOD33_MODE_Pos                _UINT32_(8)                                          /* (SYSCTRL_BOD33) Operation Modes Position */
#define SYSCTRL_BOD33_MODE_Msk                (_UINT32_(0x1) << SYSCTRL_BOD33_MODE_Pos)            /* (SYSCTRL_BOD33) Operation Modes Mask */
#define SYSCTRL_BOD33_MODE(value)             (SYSCTRL_BOD33_MODE_Msk & (_UINT32_(value) << SYSCTRL_BOD33_MODE_Pos)) /* Assignment of value for MODE in the SYSCTRL_BOD33 register */
#define SYSCTRL_BOD33_CEN_Pos                 _UINT32_(9)                                          /* (SYSCTRL_BOD33) Clock Enable Position */
#define SYSCTRL_BOD33_CEN_Msk                 (_UINT32_(0x1) << SYSCTRL_BOD33_CEN_Pos)             /* (SYSCTRL_BOD33) Clock Enable Mask */
#define SYSCTRL_BOD33_CEN(value)              (SYSCTRL_BOD33_CEN_Msk & (_UINT32_(value) << SYSCTRL_BOD33_CEN_Pos)) /* Assignment of value for CEN in the SYSCTRL_BOD33 register */
#define SYSCTRL_BOD33_PSEL_Pos                _UINT32_(12)                                         /* (SYSCTRL_BOD33) Prescaler Select Position */
#define SYSCTRL_BOD33_PSEL_Msk                (_UINT32_(0xF) << SYSCTRL_BOD33_PSEL_Pos)            /* (SYSCTRL_BOD33) Prescaler Select Mask */
#define SYSCTRL_BOD33_PSEL(value)             (SYSCTRL_BOD33_PSEL_Msk & (_UINT32_(value) << SYSCTRL_BOD33_PSEL_Pos)) /* Assignment of value for PSEL in the SYSCTRL_BOD33 register */
#define   SYSCTRL_BOD33_PSEL_DIV2_Val         _UINT32_(0x0)                                        /* (SYSCTRL_BOD33) Divide clock by 2  */
#define   SYSCTRL_BOD33_PSEL_DIV4_Val         _UINT32_(0x1)                                        /* (SYSCTRL_BOD33) Divide clock by 4  */
#define   SYSCTRL_BOD33_PSEL_DIV8_Val         _UINT32_(0x2)                                        /* (SYSCTRL_BOD33) Divide clock by 8  */
#define   SYSCTRL_BOD33_PSEL_DIV16_Val        _UINT32_(0x3)                                        /* (SYSCTRL_BOD33) Divide clock by 16  */
#define   SYSCTRL_BOD33_PSEL_DIV32_Val        _UINT32_(0x4)                                        /* (SYSCTRL_BOD33) Divide clock by 32  */
#define   SYSCTRL_BOD33_PSEL_DIV64_Val        _UINT32_(0x5)                                        /* (SYSCTRL_BOD33) Divide clock by 64  */
#define   SYSCTRL_BOD33_PSEL_DIV128_Val       _UINT32_(0x6)                                        /* (SYSCTRL_BOD33) Divide clock by 128  */
#define   SYSCTRL_BOD33_PSEL_DIV256_Val       _UINT32_(0x7)                                        /* (SYSCTRL_BOD33) Divide clock by 256  */
#define   SYSCTRL_BOD33_PSEL_DIV512_Val       _UINT32_(0x8)                                        /* (SYSCTRL_BOD33) Divide clock by 512  */
#define   SYSCTRL_BOD33_PSEL_DIV1024_Val      _UINT32_(0x9)                                        /* (SYSCTRL_BOD33) Divide clock by 1024  */
#define   SYSCTRL_BOD33_PSEL_DIV2048_Val      _UINT32_(0xA)                                        /* (SYSCTRL_BOD33) Divide clock by 2048  */
#define   SYSCTRL_BOD33_PSEL_DIV4096_Val      _UINT32_(0xB)                                        /* (SYSCTRL_BOD33) Divide clock by 4096  */
#define   SYSCTRL_BOD33_PSEL_DIV8192_Val      _UINT32_(0xC)                                        /* (SYSCTRL_BOD33) Divide clock by 8192  */
#define   SYSCTRL_BOD33_PSEL_DIV16384_Val     _UINT32_(0xD)                                        /* (SYSCTRL_BOD33) Divide clock by 16384  */
#define   SYSCTRL_BOD33_PSEL_DIV32768_Val     _UINT32_(0xE)                                        /* (SYSCTRL_BOD33) Divide clock by 32768  */
#define   SYSCTRL_BOD33_PSEL_DIV65536_Val     _UINT32_(0xF)                                        /* (SYSCTRL_BOD33) Divide clock by 65536  */
#define SYSCTRL_BOD33_PSEL_DIV2               (SYSCTRL_BOD33_PSEL_DIV2_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 2 Position */
#define SYSCTRL_BOD33_PSEL_DIV4               (SYSCTRL_BOD33_PSEL_DIV4_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 4 Position */
#define SYSCTRL_BOD33_PSEL_DIV8               (SYSCTRL_BOD33_PSEL_DIV8_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 8 Position */
#define SYSCTRL_BOD33_PSEL_DIV16              (SYSCTRL_BOD33_PSEL_DIV16_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 16 Position */
#define SYSCTRL_BOD33_PSEL_DIV32              (SYSCTRL_BOD33_PSEL_DIV32_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 32 Position */
#define SYSCTRL_BOD33_PSEL_DIV64              (SYSCTRL_BOD33_PSEL_DIV64_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 64 Position */
#define SYSCTRL_BOD33_PSEL_DIV128             (SYSCTRL_BOD33_PSEL_DIV128_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 128 Position */
#define SYSCTRL_BOD33_PSEL_DIV256             (SYSCTRL_BOD33_PSEL_DIV256_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 256 Position */
#define SYSCTRL_BOD33_PSEL_DIV512             (SYSCTRL_BOD33_PSEL_DIV512_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 512 Position */
#define SYSCTRL_BOD33_PSEL_DIV1024            (SYSCTRL_BOD33_PSEL_DIV1024_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 1024 Position */
#define SYSCTRL_BOD33_PSEL_DIV2048            (SYSCTRL_BOD33_PSEL_DIV2048_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 2048 Position */
#define SYSCTRL_BOD33_PSEL_DIV4096            (SYSCTRL_BOD33_PSEL_DIV4096_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 4096 Position */
#define SYSCTRL_BOD33_PSEL_DIV8192            (SYSCTRL_BOD33_PSEL_DIV8192_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 8192 Position */
#define SYSCTRL_BOD33_PSEL_DIV16384           (SYSCTRL_BOD33_PSEL_DIV16384_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 16384 Position */
#define SYSCTRL_BOD33_PSEL_DIV32768           (SYSCTRL_BOD33_PSEL_DIV32768_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 32768 Position */
#define SYSCTRL_BOD33_PSEL_DIV65536           (SYSCTRL_BOD33_PSEL_DIV65536_Val << SYSCTRL_BOD33_PSEL_Pos) /* (SYSCTRL_BOD33) Divide clock by 65536 Position */
#define SYSCTRL_BOD33_LEVEL_Pos               _UINT32_(16)                                         /* (SYSCTRL_BOD33) Threshold Level Position */
#define SYSCTRL_BOD33_LEVEL_Msk               (_UINT32_(0x3F) << SYSCTRL_BOD33_LEVEL_Pos)          /* (SYSCTRL_BOD33) Threshold Level Mask */
#define SYSCTRL_BOD33_LEVEL(value)            (SYSCTRL_BOD33_LEVEL_Msk & (_UINT32_(value) << SYSCTRL_BOD33_LEVEL_Pos)) /* Assignment of value for LEVEL in the SYSCTRL_BOD33 register */
#define SYSCTRL_BOD33_Msk                     _UINT32_(0x003FF35E)                                 /* (SYSCTRL_BOD33) Register Mask  */


/* -------- SYSCTRL_VREG : (SYSCTRL Offset: 0x3C) (R/W 16) VREG Control -------- */
#define SYSCTRL_VREG_RESETVALUE               _UINT16_(0x402)                                      /*  (SYSCTRL_VREG) VREG Control  Reset Value */

#define SYSCTRL_VREG_RUNSTDBY_Pos             _UINT16_(6)                                          /* (SYSCTRL_VREG) Run during Standby Position */
#define SYSCTRL_VREG_RUNSTDBY_Msk             (_UINT16_(0x1) << SYSCTRL_VREG_RUNSTDBY_Pos)         /* (SYSCTRL_VREG) Run during Standby Mask */
#define SYSCTRL_VREG_RUNSTDBY(value)          (SYSCTRL_VREG_RUNSTDBY_Msk & (_UINT16_(value) << SYSCTRL_VREG_RUNSTDBY_Pos)) /* Assignment of value for RUNSTDBY in the SYSCTRL_VREG register */
#define SYSCTRL_VREG_FORCELDO_Pos             _UINT16_(13)                                         /* (SYSCTRL_VREG) Force LDO Voltage Regulator Position */
#define SYSCTRL_VREG_FORCELDO_Msk             (_UINT16_(0x1) << SYSCTRL_VREG_FORCELDO_Pos)         /* (SYSCTRL_VREG) Force LDO Voltage Regulator Mask */
#define SYSCTRL_VREG_FORCELDO(value)          (SYSCTRL_VREG_FORCELDO_Msk & (_UINT16_(value) << SYSCTRL_VREG_FORCELDO_Pos)) /* Assignment of value for FORCELDO in the SYSCTRL_VREG register */
#define SYSCTRL_VREG_Msk                      _UINT16_(0x2040)                                     /* (SYSCTRL_VREG) Register Mask  */


/* -------- SYSCTRL_VREF : (SYSCTRL Offset: 0x40) (R/W 32) VREF Control A -------- */
#define SYSCTRL_VREF_RESETVALUE               _UINT32_(0x00)                                       /*  (SYSCTRL_VREF) VREF Control A  Reset Value */

#define SYSCTRL_VREF_TSEN_Pos                 _UINT32_(1)                                          /* (SYSCTRL_VREF) Temperature Sensor Output Enable Position */
#define SYSCTRL_VREF_TSEN_Msk                 (_UINT32_(0x1) << SYSCTRL_VREF_TSEN_Pos)             /* (SYSCTRL_VREF) Temperature Sensor Output Enable Mask */
#define SYSCTRL_VREF_TSEN(value)              (SYSCTRL_VREF_TSEN_Msk & (_UINT32_(value) << SYSCTRL_VREF_TSEN_Pos)) /* Assignment of value for TSEN in the SYSCTRL_VREF register */
#define SYSCTRL_VREF_BGOUTEN_Pos              _UINT32_(2)                                          /* (SYSCTRL_VREF) Bandgap Output Enable Position */
#define SYSCTRL_VREF_BGOUTEN_Msk              (_UINT32_(0x1) << SYSCTRL_VREF_BGOUTEN_Pos)          /* (SYSCTRL_VREF) Bandgap Output Enable Mask */
#define SYSCTRL_VREF_BGOUTEN(value)           (SYSCTRL_VREF_BGOUTEN_Msk & (_UINT32_(value) << SYSCTRL_VREF_BGOUTEN_Pos)) /* Assignment of value for BGOUTEN in the SYSCTRL_VREF register */
#define SYSCTRL_VREF_CALIB_Pos                _UINT32_(16)                                         /* (SYSCTRL_VREF) Voltage Reference Calibration Value Position */
#define SYSCTRL_VREF_CALIB_Msk                (_UINT32_(0x7FF) << SYSCTRL_VREF_CALIB_Pos)          /* (SYSCTRL_VREF) Voltage Reference Calibration Value Mask */
#define SYSCTRL_VREF_CALIB(value)             (SYSCTRL_VREF_CALIB_Msk & (_UINT32_(value) << SYSCTRL_VREF_CALIB_Pos)) /* Assignment of value for CALIB in the SYSCTRL_VREF register */
#define SYSCTRL_VREF_Msk                      _UINT32_(0x07FF0006)                                 /* (SYSCTRL_VREF) Register Mask  */


/* SYSCTRL register offsets definitions */
#define SYSCTRL_INTENCLR_REG_OFST      _UINT32_(0x00)      /* (SYSCTRL_INTENCLR) Interrupt Enable Clear Offset */
#define SYSCTRL_INTENSET_REG_OFST      _UINT32_(0x04)      /* (SYSCTRL_INTENSET) Interrupt Enable Set Offset */
#define SYSCTRL_INTFLAG_REG_OFST       _UINT32_(0x08)      /* (SYSCTRL_INTFLAG) Interrupt Flag Status and Clear Offset */
#define SYSCTRL_PCLKSR_REG_OFST        _UINT32_(0x0C)      /* (SYSCTRL_PCLKSR) Power and Clocks Status Offset */
#define SYSCTRL_XOSC_REG_OFST          _UINT32_(0x10)      /* (SYSCTRL_XOSC) External Multipurpose Crystal Oscillator (XOSC) Control Offset */
#define SYSCTRL_XOSC32K_REG_OFST       _UINT32_(0x14)      /* (SYSCTRL_XOSC32K) 32kHz External Crystal Oscillator (XOSC32K) Control Offset */
#define SYSCTRL_OSC32K_REG_OFST        _UINT32_(0x18)      /* (SYSCTRL_OSC32K) 32kHz Internal Oscillator (OSC32K) Control Offset */
#define SYSCTRL_OSCULP32K_REG_OFST     _UINT32_(0x1C)      /* (SYSCTRL_OSCULP32K) OSCULP32K Control Offset */
#define SYSCTRL_OSC8M_REG_OFST         _UINT32_(0x20)      /* (SYSCTRL_OSC8M) 8MHz Internal Oscillator (OSC8M) Control Offset */
#define SYSCTRL_DFLLCTRL_REG_OFST      _UINT32_(0x24)      /* (SYSCTRL_DFLLCTRL) DFLL Config Offset */
#define SYSCTRL_DFLLVAL_REG_OFST       _UINT32_(0x28)      /* (SYSCTRL_DFLLVAL) DFLL Calibration Value Offset */
#define SYSCTRL_DFLLMUL_REG_OFST       _UINT32_(0x2C)      /* (SYSCTRL_DFLLMUL) DFLL Multiplier Offset */
#define SYSCTRL_DFLLSYNC_REG_OFST      _UINT32_(0x30)      /* (SYSCTRL_DFLLSYNC) DFLL Synchronization Offset */
#define SYSCTRL_BOD33_REG_OFST         _UINT32_(0x34)      /* (SYSCTRL_BOD33) 3.3V Brown-Out Detector (BOD33) Control Offset */
#define SYSCTRL_VREG_REG_OFST          _UINT32_(0x3C)      /* (SYSCTRL_VREG) VREG Control Offset */
#define SYSCTRL_VREF_REG_OFST          _UINT32_(0x40)      /* (SYSCTRL_VREF) VREF Control A Offset */

#if !(defined(__ASSEMBLER__) || defined(__IAR_SYSTEMS_ASM__))
/* SYSCTRL register API structure */
typedef struct
{  /* System Control */
  __IO  uint32_t                       SYSCTRL_INTENCLR;   /* Offset: 0x00 (R/W  32) Interrupt Enable Clear */
  __IO  uint32_t                       SYSCTRL_INTENSET;   /* Offset: 0x04 (R/W  32) Interrupt Enable Set */
  __IO  uint32_t                       SYSCTRL_INTFLAG;    /* Offset: 0x08 (R/W  32) Interrupt Flag Status and Clear */
  __I   uint32_t                       SYSCTRL_PCLKSR;     /* Offset: 0x0C (R/   32) Power and Clocks Status */
  __IO  uint16_t                       SYSCTRL_XOSC;       /* Offset: 0x10 (R/W  16) External Multipurpose Crystal Oscillator (XOSC) Control */
  __I   uint8_t                        Reserved1[0x02];
  __IO  uint16_t                       SYSCTRL_XOSC32K;    /* Offset: 0x14 (R/W  16) 32kHz External Crystal Oscillator (XOSC32K) Control */
  __I   uint8_t                        Reserved2[0x02];
  __IO  uint32_t                       SYSCTRL_OSC32K;     /* Offset: 0x18 (R/W  32) 32kHz Internal Oscillator (OSC32K) Control */
  __IO  uint8_t                        SYSCTRL_OSCULP32K;  /* Offset: 0x1C (R/W  8) OSCULP32K Control */
  __I   uint8_t                        Reserved3[0x03];
  __IO  uint32_t                       SYSCTRL_OSC8M;      /* Offset: 0x20 (R/W  32) 8MHz Internal Oscillator (OSC8M) Control */
  __IO  uint16_t                       SYSCTRL_DFLLCTRL;   /* Offset: 0x24 (R/W  16) DFLL Config */
  __I   uint8_t                        Reserved4[0x02];
  __IO  uint32_t                       SYSCTRL_DFLLVAL;    /* Offset: 0x28 (R/W  32) DFLL Calibration Value */
  __IO  uint32_t                       SYSCTRL_DFLLMUL;    /* Offset: 0x2C (R/W  32) DFLL Multiplier */
  __IO  uint8_t                        SYSCTRL_DFLLSYNC;   /* Offset: 0x30 (R/W  8) DFLL Synchronization */
  __I   uint8_t                        Reserved5[0x03];
  __IO  uint32_t                       SYSCTRL_BOD33;      /* Offset: 0x34 (R/W  32) 3.3V Brown-Out Detector (BOD33) Control */
  __I   uint8_t                        Reserved6[0x04];
  __IO  uint16_t                       SYSCTRL_VREG;       /* Offset: 0x3C (R/W  16) VREG Control */
  __I   uint8_t                        Reserved7[0x02];
  __IO  uint32_t                       SYSCTRL_VREF;       /* Offset: 0x40 (R/W  32) VREF Control A */
} sysctrl_registers_t;


#endif /* !(defined(__ASSEMBLER__) || defined(__IAR_SYSTEMS_ASM__)) */
#endif /* _PIC32CMGV00_SYSCTRL_COMPONENT_H_ */
