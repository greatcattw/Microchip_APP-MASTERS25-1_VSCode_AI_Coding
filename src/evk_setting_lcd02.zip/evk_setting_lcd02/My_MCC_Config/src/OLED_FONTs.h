#ifndef OLED_FONTS_H
#define OLED_FONTS_H
extern const unsigned char Font16x16[][32];
extern const unsigned char Font6x8[][6];
extern const unsigned char Font8x16[][16];
#endif
