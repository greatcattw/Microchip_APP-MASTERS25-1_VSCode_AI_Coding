/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "OLED128x64.h"

// *************************************************
// 使用 TC5 來控制 WS2812 時須將此選定義註解符號去掉
// #define WS2812_USE_TC5
// **************************************************

#define KXTJ3_ADDR      0x0e            
#define BME280_ADDR     0x76

union
{
    char   ByteVal[2];
    int    WordValue ;
}KXTJ3_XOUT;

union
{
    char   ByteVal[2];
    int    WordValue ;
}KXTJ3_YOUT;

union
{
    char   ByteVal[2];
    int    WordValue ;
}KXTJ3_ZOUT;

volatile unsigned char  I2C_Wbuffer[16];   
volatile unsigned char  I2C_Rbuffer[16] ;

uint8_t             StateMachine = 0 ;
volatile bool       bTC0_Timeout = 0 ;
volatile uint8_t    WS2812_Pattern[128];
volatile uint8_t    WS2812_Index = 0 ;
volatile bool       bIsI2C_DONE = true ;
unsigned int        ADC_Result ;
uint8_t             ASCII_Buffer[24];

typedef enum  COLOR_CODE{
    GREEN = 0 ,
    RED,
    BLUE,
    DARK
}WS2812_COLOR;

void    WS2812_Pattern_Update(WS2812_COLOR, WS2812_COLOR, WS2812_COLOR);
void    WS2812_Update(void);



void TC0_Callback_InterruptHandler(TC_TIMER_STATUS status, uintptr_t context)
{
    /* Toggle LED */
    bTC0_Timeout = 1 ;
    switch (StateMachine)
    {
        case 0:
            PWM1_Set();
            PWM2_Clear();
            PWM3_Clear();
            StateMachine++;
            break;
        case 1:
            PWM1_Clear();
            PWM2_Set();
            PWM3_Clear();           
            StateMachine++;
            break;
        case 2:
            PWM1_Clear();
            PWM2_Clear();
            PWM3_Set();            
            StateMachine=0;
            break;
        default:
            PWM1_Clear();
            PWM2_Clear();
            PWM3_Clear();            
            StateMachine=0;           
            break;
    }
}

// --------------------------------------------------------------------------
// 如果使用 TC5 的時候會使用到此中斷服務程式
// --------------------------------------------------------------------------
void TC5_Callback_InterruptHandler(TC_TIMER_STATUS status, uintptr_t context)
{
        TC5_REGS->COUNT8.TC_CC[1] = WS2812_Pattern[WS2812_Index++];
        if (WS2812_Index == 73)
        {
            TC5_CompareStop();
            TC5_Compare8bitMatch1Set(0);
        }
}

void    I2C_EventHandler(uintptr_t  contest)
{
    if (SERCOM2_I2C_ErrorGet() == SERCOM_I2C_ERROR_NONE )
        bIsI2C_DONE = true ;
}

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main ( void )
{
    uint8_t Traffic_Code;
    /* Initialize all modules */
    SYS_Initialize ( NULL );
   
    
    SERCOM2_I2C_CallbackRegister(I2C_EventHandler,0) ;
    TC5_CompareCallbackRegister(TC5_Callback_InterruptHandler,(uintptr_t)NULL );
    TC0_TimerCallbackRegister(TC0_Callback_InterruptHandler, (uintptr_t)NULL);
    TC0_TimerStart();
    TC5_Compare8bitMatch1Set(0);
    
    bTC0_Timeout = 0 ;
    while (bTC0_Timeout ==0) ;
    bTC0_Timeout = 0 ;
    
    TC3_CompareStop();
    
    ADC_Enable();
    
        OLED_Init();
        OLED_CLS();
        OLED_Put8x16Str(0, 0, (const unsigned char*) "APP-MASTERS25-1") ;    
        OLED_Put8x16Str(0, 2, (const unsigned char*) " PIC32CM3204GV") ;    
        OLED_Put8x16Str(0, 4, (const unsigned char*) "VR =  ") ;
        OLED_Put8x16Str(0, 6, (const unsigned char*) "XYZ=  ") ;
                
                bIsI2C_DONE = false ;
                I2C_Wbuffer[0] = 0xd0 ;     // Read ID information from BME280
                SERCOM2_I2C_WriteRead(BME280_ADDR,I2C_Wbuffer,1,I2C_Rbuffer,1);
                while ( bIsI2C_DONE == false) ;
                
                if (I2C_Rbuffer[0] != 0x60)
                {
                    OLED_Put8x16Str(0,6,"BME280 Fail");
                    while (1) ;
                }        
                
                bIsI2C_DONE = false ;                               // Initialize KXTJ3 
                I2C_Wbuffer[0] = 0x1b ;
                I2C_Wbuffer[1] = 0x80 ;
                SERCOM2_I2C_Write(KXTJ3_ADDR, I2C_Wbuffer, 2);     
                while (bIsI2C_DONE == false) ;               
               

    Traffic_Code = 0 ;
    while ( true )
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );
        if (bTC0_Timeout)
        {
            if (MCU_S1_Get())
                TC3_CompareStop();
            else
                TC3_CompareStart();
            
            if (MCU_S2_Get())
                {
                    LED1_Clear();
                    LED2_Clear();
                    LED3_Clear();
                    LED4_Clear();
                }
            else
                {
                    LED1_Toggle();
                    LED2_Toggle();
                    LED3_Toggle();
                    LED4_Toggle();
                }                
                   
                 // -------------
                // -- Read KXTJ3 to KXTJ3_XOUT, KXTJ3_YOUT , KXTJ3_ZOUT
                // -------------
                I2C_Wbuffer[0] = 0x6 ;
                SERCOM2_I2C_WriteRead(KXTJ3_ADDR,I2C_Wbuffer,1,I2C_Rbuffer,6);
                while ( bIsI2C_DONE == false) ;
                
                KXTJ3_XOUT.ByteVal[0] = I2C_Rbuffer[0];
                KXTJ3_XOUT.ByteVal[1] = I2C_Rbuffer[1];     
                    KXTJ3_YOUT.ByteVal[0] = I2C_Rbuffer[2];
                    KXTJ3_YOUT.ByteVal[1] = I2C_Rbuffer[3];      
                        KXTJ3_ZOUT.ByteVal[0] = I2C_Rbuffer[4];
                        KXTJ3_ZOUT.ByteVal[1] = I2C_Rbuffer[5];    
                        

                sprintf (ASCII_Buffer," %3d %3d %3d\0", KXTJ3_XOUT.ByteVal[1],  KXTJ3_YOUT.ByteVal[1], KXTJ3_ZOUT.ByteVal[1]) ;
                OLED_Put8x16Str(32,6,ASCII_Buffer) ;  
                       
            
              bTC0_Timeout = 0 ;
              
              ADC_ConversionStart();
              while(!ADC_ConversionStatusGet());
              ADC_Result = ADC_ConversionResultGet();
              
              printf ("APP-MASTERS25-1 ADC = %5d\n\r",ADC_Result);
              sprintf(ASCII_Buffer," %4d\0",ADC_Result);
              OLED_Put8x16Str(48,4, ASCII_Buffer) ;      
              switch (Traffic_Code)
              {
                  case 0:
                      WS2812_Pattern_Update(RED, DARK, DARK);
                      Traffic_Code++;
                      break;
                  case 1:
                      WS2812_Pattern_Update(DARK, DARK, DARK);
                      Traffic_Code++;                      
                      break;
                  case 2:
                      WS2812_Pattern_Update(DARK, GREEN, DARK);
                      Traffic_Code++;                      
                      break;
                  case 3:
                      WS2812_Pattern_Update(DARK, DARK, DARK);
                      Traffic_Code++;                          
                      break;
                  case 4:
                      WS2812_Pattern_Update(DARK, DARK, BLUE);
                      Traffic_Code++;                      
                      break;
                  case 5:
                      WS2812_Pattern_Update(DARK, DARK, DARK);
                      Traffic_Code++;                          
                      break;     
                  case 6:
                      WS2812_Pattern_Update(GREEN, GREEN, GREEN);
                      Traffic_Code++;                      
                      break;
                  case 7:
                      WS2812_Pattern_Update(RED, RED, RED);
                      Traffic_Code++;                          
                      break;             
                  case 8:
                      WS2812_Pattern_Update(BLUE, BLUE, BLUE);
                      Traffic_Code++;    
                      break;
                  case 9:
                      WS2812_Pattern_Update(DARK, DARK, DARK);
                      Traffic_Code= 0;   
                      break;                      
                      
              }
              
#ifdef WS2812_USE_TC5
              
            WS2812_Index = 0 ;  
            TC5_Compare8bitMatch1Set(0);
            TC5_CompareStart();
#else
            __disable_irq(); 
               WS2812_Update();
            __enable_irq();                        
#endif
              
        }
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}

void    WS2812_Pattern_Update(enum  COLOR_CODE color1, enum  COLOR_CODE color2, enum  COLOR_CODE color3)
{
    unsigned char   Loop1 ;
    
#ifdef  WS2812_USE_TC5
    
    for (Loop1 = 0; Loop1 < 72; Loop1++)
    {
        WS2812_Pattern[Loop1] = 10 ;    
    }    
    
    switch (color1)
    {
        case    GREEN:
                WS2812_Pattern[4]  = 30;
                break;
        case    RED:
                WS2812_Pattern[12]  = 30;
                break;            
        case    BLUE:
                WS2812_Pattern[20]  = 30;
                break; 
        default :
                break;
                        
    }
    switch (color2)
    {
        case    GREEN:
                WS2812_Pattern[28]  = 30;
                break;
        case    RED:
                WS2812_Pattern[36]  = 30;
                break;            
        case    BLUE:
                WS2812_Pattern[44]  = 30;
                break; 
        default :
                break;                                        
    }
    
    switch (color3)
    {
        case    GREEN:
                WS2812_Pattern[52]  = 30;
                break;
        case    RED:
                WS2812_Pattern[60]  = 30;
                break;            
        case    BLUE:
                WS2812_Pattern[68]  = 30;
                break; 
        default :
                break;
                        
    }    
    
#else
    for (Loop1 = 0; Loop1 < 72; Loop1++)
    {
        WS2812_Pattern[Loop1] = 0 ;    
    }    
    
    switch (color1)
    {
        case    GREEN:
                WS2812_Pattern[3]  = 1;
                break;
        case    RED:
                WS2812_Pattern[11]  = 1;
                break;            
        case    BLUE:
                WS2812_Pattern[19]  = 1;
                break; 
        default :
                break;
                        
    }
    switch (color2)
    {
        case    GREEN:
                WS2812_Pattern[27]  = 1;
                break;
        case    RED:
                WS2812_Pattern[35]  = 1;
                break;            
        case    BLUE:
                WS2812_Pattern[43]  = 1;
                break; 
        default :
                break;                                        
    }
    
    switch (color3)
    {
        case    GREEN:
                WS2812_Pattern[51]  = 1;
                break;
        case    RED:
                WS2812_Pattern[59]  = 1;
                break;            
        case    BLUE:
                WS2812_Pattern[67]  = 1;
                break; 
        default :
                break;
                        
    }    
#endif
}

void WS2812_Update(void)
{
            for (WS2812_Index = 0; WS2812_Index < 72; WS2812_Index)
            {
                
                if (WS2812_Pattern[WS2812_Index++])
                {
                    PIN_WS2812_Set();
                    PIN_WS2812_Set();                 
                    PIN_WS2812_Set();
                    PIN_WS2812_Set();
                    PIN_WS2812_Set();
                    PIN_WS2812_Set();
                    PIN_WS2812_Set();    
                    PIN_WS2812_Set();
                    PIN_WS2812_Clear();    
    
                }
                else
                {   
                    PIN_WS2812_Set(); 
                    PIN_WS2812_Set();    
                    PIN_WS2812_Set();                    
                    PIN_WS2812_Set();
                    PIN_WS2812_Clear();
                    PIN_WS2812_Clear();
                    PIN_WS2812_Clear();
                    PIN_WS2812_Clear();       
                    PIN_WS2812_Clear();
                    PIN_WS2812_Clear();                      
                }         
            }    
    
}


/*******************************************************************************
 End of File
*/

